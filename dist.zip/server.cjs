var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server.ts
var server_exports = {};
__export(server_exports, {
  activeTrades: () => activeTrades2,
  authMiddleware: () => authMiddleware,
  getMaskedSettings: () => getMaskedSettings,
  historicalLogs: () => historicalLogs2,
  systemSettings: () => systemSettings
});
module.exports = __toCommonJS(server_exports);
var import_config = require("dotenv/config");
var import_express9 = __toESM(require("express"), 1);
var import_path9 = __toESM(require("path"), 1);
var import_fs9 = __toESM(require("fs"), 1);
var import_vite = require("vite");

// src/server/routes/risk.ts
var import_express2 = require("express");

// src/server/state.ts
var import_path2 = __toESM(require("path"), 1);
var import_fs2 = __toESM(require("fs"), 1);

// src/server/edgeBridge.ts
var import_net = __toESM(require("net"), 1);
var EdgeBridgeClient = class {
  constructor() {
    this.host = process.env.EDGE_NODE_HOST || process.env.EDGE_NODE_IP || "127.0.0.1";
    this.port = Number(process.env.EDGE_TCP_PORT) || 4005;
    this.authToken = process.env.EDGE_AUTH_TOKEN || "ALPHA_EDGE_SECRET_2026";
  }
  getHost() {
    return process.env.EDGE_NODE_HOST || process.env.EDGE_NODE_IP || this.host;
  }
  getPort() {
    return Number(process.env.EDGE_TCP_PORT) || this.port;
  }
  /**
   * Sends a single newline-delimited JSON command over a raw TCP socket and awaits the JSON response.
   */
  async sendCommand(payload, timeoutMs = 3e3) {
    const targetHost = this.getHost();
    const targetPort = this.getPort();
    return new Promise((resolve, reject) => {
      const socket = new import_net.default.Socket();
      let responseData = "";
      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          socket.destroy();
          reject(new Error(`Edge TCP Bridge timeout after ${timeoutMs}ms connecting to ${targetHost}:${targetPort}`));
        }
      }, timeoutMs);
      socket.connect(targetPort, targetHost, () => {
        const fullPayload = {
          ...payload,
          token: this.authToken,
          timestamp: Date.now() / 1e3
        };
        socket.write(JSON.stringify(fullPayload) + "\n");
      });
      socket.on("data", (chunk) => {
        responseData += chunk.toString("utf-8");
        if (responseData.includes("\n")) {
          const lines = responseData.split("\n");
          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.length > 0) {
              if (!settled) {
                settled = true;
                clearTimeout(timer);
                socket.end();
                try {
                  const parsed = JSON.parse(trimmed);
                  resolve(parsed);
                } catch (parseErr) {
                  reject(new Error(`Edge TCP Bridge received invalid JSON: ${trimmed}`));
                }
              }
              break;
            }
          }
        }
      });
      socket.on("error", (err) => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          socket.destroy();
          reject(err);
        }
      });
      socket.on("close", () => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          reject(new Error("Edge TCP Bridge connection closed prematurely"));
        }
      });
    });
  }
  /**
   * Measures true round-trip TCP latency in milliseconds.
   */
  async measureLatency() {
    const t0 = performance.now();
    try {
      await this.sendCommand({ action: "PING" }, 1500);
      const t1 = performance.now();
      return Math.round((t1 - t0) * 10) / 10;
    } catch (e) {
      return 0;
    }
  }
  /**
   * Submits a live or paper order directly to the Frankfurt edge execution daemon.
   */
  async submitOrder(order) {
    return this.sendCommand({
      action: "SUBMIT_ORDER",
      order
    });
  }
  /**
   * Triggers an emergency portfolio liquidation directly on the Frankfurt edge node.
   */
  async triggerEmergencyFlush() {
    return this.sendCommand({
      action: "EMERGENCY_FLUSH"
    });
  }
  /**
   * Synchronizes updated risk parameters and trading mode (PAPER/LIVE) to edge daemon.
   */
  async syncSettings(settings) {
    return this.sendCommand({
      action: "UPDATE_SETTINGS",
      settings
    });
  }
  /**
   * Dispatches any official IBKR inquiry or command directly to the edge daemon.
   */
  async dispatchIbkr(method, args = {}, timeoutMs = 4e3) {
    return this.sendCommand({
      action: "DISPATCH_IBKR",
      method,
      args
    }, timeoutMs);
  }
  /**
   * Queries official closing price, NBBO, and 5-day candlestick history from IBKR.
   */
  async getMarketQuote(symbol, timeoutMs = 4e3) {
    return this.sendCommand({
      action: "GET_QUOTE",
      symbol
    }, timeoutMs);
  }
  /**
   * Dispatches an on-demand IPC trigger to the Frankfurt edge node gateway autologin daemon.
   */
  async triggerGatewayLogin(timeoutMs = 3e3) {
    return this.sendCommand({
      action: "TRIGGER_GATEWAY_LOGIN"
    }, timeoutMs);
  }
};
var edgeBridge = new EdgeBridgeClient();

// src/server/vault.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var PRODUCTION_SECRETS_PATH = "/etc/alpha-engine/secrets.env";
var LOCAL_SECRETS_PATH = import_path.default.join(process.cwd(), ".env");
function getSecretsFilePath() {
  if (process.env.ALPHA_SECRETS_PATH && import_fs.default.existsSync(process.env.ALPHA_SECRETS_PATH)) {
    return process.env.ALPHA_SECRETS_PATH;
  }
  if (import_fs.default.existsSync(PRODUCTION_SECRETS_PATH)) {
    return PRODUCTION_SECRETS_PATH;
  }
  return LOCAL_SECRETS_PATH;
}
function parseEnvFile(filePath) {
  const result = {};
  if (!import_fs.default.existsSync(filePath)) return result;
  try {
    const content = import_fs.default.readFileSync(filePath, "utf-8");
    for (const line of content.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const idx = trimmed.indexOf("=");
      if (idx !== -1) {
        const key = trimmed.slice(0, idx).trim();
        let val = trimmed.slice(idx + 1).trim();
        if (val.startsWith('"') && val.endsWith('"') || val.startsWith("'") && val.endsWith("'")) {
          val = val.slice(1, -1);
        }
        result[key] = val;
      }
    }
  } catch (err) {
    console.warn(`[VAULT] Notice: Could not read secrets file ${filePath}:`, err.message);
  }
  return result;
}
function loadVaultCredentials() {
  const fileEnv = parseEnvFile(getSecretsFilePath());
  const getVal = (envKey, fallback = "") => {
    return process.env[envKey] || fileEnv[envKey] || fallback;
  };
  const defaultFallbackHost = process.env.K_SERVICE ? "10.156.0.2" : "127.0.0.1";
  const edgeHost = getVal("EDGE_NODE_HOST") || getVal("EDGE_NODE_IP") || getVal("IBKR_HOST", defaultFallbackHost);
  const edgePort = Number(getVal("EDGE_TCP_PORT", "4005")) || 4005;
  return {
    // Pillar 1: Brokerage
    ibkrAccountNumber: getVal("IBKR_ACCOUNT_NUMBER", ""),
    ibkrLiveAccountNumber: getVal("IBKR_LIVE_ACCOUNT_NUMBER", ""),
    ibkrPaperAccountNumber: getVal("IBKR_PAPER_ACCOUNT_NUMBER", ""),
    ibkrHost: edgeHost,
    ibkrPort: Number(getVal("IBKR_PORT", "4002")) || 4002,
    ibkrClientId: Number(getVal("IBKR_CLIENT_ID", "10")) || 10,
    ibkrPaperUsername: getVal("IBKR_PAPER_USERNAME", ""),
    ibkrPaperPassword: getVal("IBKR_PAPER_PASSWORD", ""),
    ibkrLiveUsername: getVal("IBKR_LIVE_USERNAME", ""),
    ibkrLivePassword: getVal("IBKR_LIVE_PASSWORD", ""),
    mifid2DecisionMaker: getVal("MIFID2_DECISION_MAKER_ID", "ALGO_DEC_992"),
    mifid2ExecutionTrader: getVal("MIFID2_EXECUTION_TRADER_ID", "ALGO_EXE_554"),
    // Pillar 2: Cloud & Edge Node
    edgeNodeHost: edgeHost,
    edgeTcpPort: edgePort,
    edgeAuthToken: getVal("EDGE_AUTH_TOKEN", "ALPHA_EDGE_SECRET_2026"),
    tradingMode: getVal("TRADING_MODE", "PAPER").toUpperCase() === "LIVE" ? "LIVE" : "PAPER",
    adminOperatorKey: getVal("OPERATOR_ADMIN_KEY") || getVal("ADMIN_OPERATOR_KEY", "ALPHA_ADMIN_REVERT_992"),
    // Pillar 3: AI Model Providers
    geminiApiKey: getVal("GEMINI_API_KEY", ""),
    groqApiKey: getVal("GROQ_API_KEY", "") || getVal("CUSTOM_AI_API_KEY", ""),
    customAiApiKey: getVal("CUSTOM_AI_API_KEY", "") || getVal("GROQ_API_KEY", ""),
    nvidiaApiKey: getVal("NVIDIA_API_KEY", "") || getVal("NVIDIA_INFERENCE_API_KEY", ""),
    openaiApiKey: getVal("OPENAI_API_KEY", ""),
    anthropicApiKey: getVal("ANTHROPIC_API_KEY", ""),
    openrouterApiKey: getVal("OPENROUTER_API_KEY", ""),
    customAiBaseUrl: getVal("CUSTOM_AI_BASE_URL", "http://localhost:11434/v1"),
    customAiModelName: getVal("CUSTOM_AI_MODEL_NAME", "llama3.1"),
    selectedAiProvider: getVal("SELECTED_AI_PROVIDER", "gemini-flash"),
    // Pillar 4: Feeds
    secUserAgent: getVal("SEC_USER_AGENT", "AlphaEngine/2.0 (InstitutionalResearch; contact@alphaengine.internal)"),
    openFdaApiKey: getVal("OPENFDA_API_KEY", ""),
    fredApiKey: getVal("FRED_API_KEY", ""),
    patentsApiKey: getVal("PATENTS_API_KEY", "")
  };
}
function maskSecret(val, fullMask = false) {
  if (!val || typeof val !== "string" || val.trim().length === 0) return "";
  const trimmed = val.trim();
  if (fullMask) return "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
  if (trimmed.length <= 8) return "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
  return `${trimmed.slice(0, 4)}...${trimmed.slice(-4)}`;
}
function isMaskedString(val) {
  if (!val || typeof val !== "string") return false;
  const s = val.trim();
  return s.includes("...") || s.includes("\u2022\u2022\u2022\u2022") || s === "configured";
}
function getMaskedVaultCredentials() {
  const creds = loadVaultCredentials();
  return {
    ...creds,
    ibkrPaperPassword: maskSecret(creds.ibkrPaperPassword, true),
    ibkrLivePassword: maskSecret(creds.ibkrLivePassword, true),
    edgeAuthToken: maskSecret(creds.edgeAuthToken),
    adminOperatorKey: maskSecret(creds.adminOperatorKey),
    geminiApiKey: maskSecret(creds.geminiApiKey),
    groqApiKey: maskSecret(creds.groqApiKey),
    customAiApiKey: maskSecret(creds.customAiApiKey),
    nvidiaApiKey: maskSecret(creds.nvidiaApiKey),
    openaiApiKey: maskSecret(creds.openaiApiKey),
    anthropicApiKey: maskSecret(creds.anthropicApiKey),
    openrouterApiKey: maskSecret(creds.openrouterApiKey),
    openFdaApiKey: maskSecret(creds.openFdaApiKey),
    fredApiKey: maskSecret(creds.fredApiKey),
    patentsApiKey: maskSecret(creds.patentsApiKey),
    hasGeminiKey: !!(creds.geminiApiKey && creds.geminiApiKey.length >= 20),
    hasGroqKey: !!(creds.groqApiKey && creds.groqApiKey.length >= 15),
    hasNvidiaKey: !!(creds.nvidiaApiKey && creds.nvidiaApiKey.length >= 15),
    hasOpenaiKey: !!(creds.openaiApiKey && creds.openaiApiKey.length >= 15),
    hasAnthropicKey: !!(creds.anthropicApiKey && creds.anthropicApiKey.length >= 15),
    hasOpenrouterKey: !!(creds.openrouterApiKey && creds.openrouterApiKey.length >= 15),
    hasOpenFdaKey: !!creds.openFdaApiKey,
    hasFredKey: !!creds.fredApiKey,
    hasPatentsKey: !!creds.patentsApiKey
  };
}
function saveVaultCredentials(updates) {
  const current = loadVaultCredentials();
  const sanitizedUpdates = {};
  for (const [k, v] of Object.entries(updates)) {
    if (v !== void 0 && v !== null) {
      if (typeof v === "string" && isMaskedString(v)) {
        continue;
      }
      sanitizedUpdates[k] = v;
    }
  }
  const merged = { ...current, ...sanitizedUpdates };
  const envMap = {
    IBKR_ACCOUNT_NUMBER: merged.ibkrAccountNumber,
    IBKR_LIVE_ACCOUNT_NUMBER: merged.ibkrLiveAccountNumber || "",
    IBKR_PAPER_ACCOUNT_NUMBER: merged.ibkrPaperAccountNumber || "",
    IBKR_HOST: merged.ibkrHost,
    IBKR_PORT: String(merged.ibkrPort),
    IBKR_CLIENT_ID: String(merged.ibkrClientId),
    IBKR_PAPER_USERNAME: merged.ibkrPaperUsername || "",
    IBKR_PAPER_PASSWORD: merged.ibkrPaperPassword || "",
    IBKR_LIVE_USERNAME: merged.ibkrLiveUsername || "",
    IBKR_LIVE_PASSWORD: merged.ibkrLivePassword || "",
    MIFID2_DECISION_MAKER_ID: merged.mifid2DecisionMaker,
    MIFID2_EXECUTION_TRADER_ID: merged.mifid2ExecutionTrader,
    EDGE_NODE_HOST: merged.edgeNodeHost,
    EDGE_NODE_IP: merged.edgeNodeHost,
    EDGE_TCP_PORT: String(merged.edgeTcpPort),
    EDGE_AUTH_TOKEN: merged.edgeAuthToken,
    TRADING_MODE: merged.tradingMode,
    ADMIN_OPERATOR_KEY: merged.adminOperatorKey,
    OPERATOR_ADMIN_KEY: merged.adminOperatorKey,
    GEMINI_API_KEY: merged.geminiApiKey,
    GROQ_API_KEY: merged.groqApiKey,
    CUSTOM_AI_API_KEY: merged.customAiApiKey,
    NVIDIA_API_KEY: merged.nvidiaApiKey,
    OPENAI_API_KEY: merged.openaiApiKey,
    ANTHROPIC_API_KEY: merged.anthropicApiKey,
    OPENROUTER_API_KEY: merged.openrouterApiKey || "",
    CUSTOM_AI_BASE_URL: merged.customAiBaseUrl,
    CUSTOM_AI_MODEL_NAME: merged.customAiModelName,
    SELECTED_AI_PROVIDER: merged.selectedAiProvider,
    SEC_USER_AGENT: merged.secUserAgent,
    OPENFDA_API_KEY: merged.openFdaApiKey,
    FRED_API_KEY: merged.fredApiKey,
    PATENTS_API_KEY: merged.patentsApiKey
  };
  for (const [k, v] of Object.entries(envMap)) {
    if (v !== void 0) {
      process.env[k] = v;
    }
  }
  let targetPath = PRODUCTION_SECRETS_PATH;
  try {
    const dir = import_path.default.dirname(targetPath);
    if (!import_fs.default.existsSync(dir)) {
      import_fs.default.mkdirSync(dir, { recursive: true, mode: 448 });
    }
  } catch {
    targetPath = LOCAL_SECRETS_PATH;
  }
  const tmpPath = `${targetPath}.tmp.${Date.now()}`;
  const lines = [
    "# AlphaEngine 12-Factor Decoupled Secrets Vault",
    "# Auto-generated via AlphaEngine Control Plane. Strictly Protected (chmod 600).",
    `# Updated At: ${(/* @__PURE__ */ new Date()).toISOString()}`,
    ""
  ];
  for (const [k, v] of Object.entries(envMap)) {
    lines.push(`${k}="${v.replace(/"/g, '\\"')}"`);
  }
  lines.push("");
  try {
    import_fs.default.writeFileSync(tmpPath, lines.join("\n"), { encoding: "utf-8", mode: 384 });
    import_fs.default.renameSync(tmpPath, targetPath);
    console.log(`[VAULT] Successfully persisted 12-factor secrets atomically to ${targetPath}`);
  } catch (err) {
    console.error(`[VAULT ERROR] Could not persist secrets to ${targetPath}:`, err.message);
    if (import_fs.default.existsSync(tmpPath)) {
      try {
        import_fs.default.unlinkSync(tmpPath);
      } catch {
      }
    }
  }
  return merged;
}

// src/server/state.ts
var SETTINGS_FILE_PATH = import_path2.default.join(process.cwd(), "system_settings.json");
var systemSettings = {
  ibkrAccountNumber: process.env.IBKR_ACCOUNT_NUMBER || "",
  ibkrHost: process.env.EDGE_NODE_IP || "127.0.0.1",
  ibkrPort: 4002,
  ibkrClientId: 10,
  mifid2DecisionMaker: "ALGO_DEC_992",
  mifid2ExecutionTrader: "ALGO_EXE_554",
  referenceEquity: 102393083e-2,
  netLiquidation: 102393083e-2,
  maintenanceMargin: 11901.58,
  routerLocked: false,
  marketTime: "10:30",
  marketPhase: "EXECUTION",
  virtualCapitalCeiling: 25e3,
  dailyCapitalCeiling: 1e4,
  dailyMaxLossCutoff: 250,
  tradeRiskPercent: 1,
  dailyLossMode: "R_MULTIPLE",
  dailyLossRMultiple: 4,
  fractionalTradingEnabled: true,
  intradayFlatteningEnabled: true,
  intradayFlattenTimeEST: "15:45",
  intradayFlattenTimeCET: "17:15",
  killSwitchEngaged: false,
  tradingMode: "PAPER",
  marketScope: "ALL",
  gatewayConnectionActive: false,
  dailyDrawdownLimitPercent: 2.5,
  dailyDrawdownLimitCash: 3e3,
  stopAtrMultiplier: 1.8,
  partialProfit: true,
  breakevenLock: true,
  maxHoldBars: 15,
  ofiFilter: true,
  adaptiveStop: true,
  geminiApiKey: "",
  openaiApiKey: "",
  anthropicApiKey: "",
  nvidiaApiKey: "",
  customAiApiKey: "",
  customAiBaseUrl: "",
  customAiModelName: "",
  selectedAiProvider: "gemini-flash",
  openrouterApiKey: "",
  openFdaApiKey: "",
  fredApiKey: "",
  patentsApiKey: "",
  secUserAgent: "AlphaEngine/2.0 (InstitutionalResearch; contact@alphaengine.internal)"
};
var activeTrades = [];
var historicalLogs = [];
var marketBooks = {};
var dynamicBaskets = [];
try {
  const dbPath = import_path2.default.join(process.cwd(), "dynamic_baskets.json");
  if (import_fs2.default.existsSync(dbPath)) {
    const raw = JSON.parse(import_fs2.default.readFileSync(dbPath, "utf-8"));
    dynamicBaskets = raw.baskets || [];
    console.log(`[STATE] Ingested ${dynamicBaskets.length} dynamic candidate baskets from disk on initialization.`);
  }
} catch (e) {
  console.warn("[STATE] Could not read dynamic_baskets.json on boot:", e.message);
}
var executionBlotter = [];
async function persistSettings() {
  try {
    import_fs2.default.writeFileSync(SETTINGS_FILE_PATH, JSON.stringify(systemSettings, null, 2), "utf-8");
    console.log("[SETTINGS] System settings successfully persisted to local storage.");
    edgeBridge.syncSettings(systemSettings).catch((err) => {
      console.warn("[EDGE BRIDGE WARN] Async edge settings sync queued or offline:", err.message);
    });
  } catch (err) {
    console.error("[SETTINGS] Failed to persist settings to disk:", err.message);
  }
}
async function loadPersistentSettings() {
  try {
    if (import_fs2.default.existsSync(SETTINGS_FILE_PATH)) {
      const data = JSON.parse(import_fs2.default.readFileSync(SETTINGS_FILE_PATH, "utf-8"));
      if (data) {
        systemSettings = { ...systemSettings, ...data };
        console.log("[SETTINGS] System settings successfully restored from disk.");
      }
    } else {
      console.log("[SETTINGS] No existing settings file found on disk. Initializing defaults.");
      await persistSettings();
    }
    const vaultCreds = loadVaultCredentials();
    systemSettings.geminiApiKey = vaultCreds.geminiApiKey || systemSettings.geminiApiKey;
    systemSettings.customAiApiKey = vaultCreds.customAiApiKey || systemSettings.customAiApiKey;
    systemSettings.nvidiaApiKey = vaultCreds.nvidiaApiKey || systemSettings.nvidiaApiKey;
    systemSettings.openaiApiKey = vaultCreds.openaiApiKey || systemSettings.openaiApiKey;
    systemSettings.anthropicApiKey = vaultCreds.anthropicApiKey || systemSettings.anthropicApiKey;
    systemSettings.customAiBaseUrl = vaultCreds.customAiBaseUrl || systemSettings.customAiBaseUrl;
    systemSettings.customAiModelName = vaultCreds.customAiModelName || systemSettings.customAiModelName;
    systemSettings.selectedAiProvider = vaultCreds.selectedAiProvider || systemSettings.selectedAiProvider;
    systemSettings.openFdaApiKey = vaultCreds.openFdaApiKey || systemSettings.openFdaApiKey;
    systemSettings.fredApiKey = vaultCreds.fredApiKey || systemSettings.fredApiKey;
    systemSettings.patentsApiKey = vaultCreds.patentsApiKey || systemSettings.patentsApiKey;
    systemSettings.secUserAgent = vaultCreds.secUserAgent || systemSettings.secUserAgent;
    systemSettings.ibkrHost = vaultCreds.edgeNodeHost || systemSettings.ibkrHost;
    systemSettings.ibkrPort = vaultCreds.ibkrPort || systemSettings.ibkrPort;
    systemSettings.ibkrClientId = vaultCreds.ibkrClientId || systemSettings.ibkrClientId;
    systemSettings.ibkrAccountNumber = vaultCreds.ibkrAccountNumber || systemSettings.ibkrAccountNumber;
    systemSettings.ibkrLiveAccountNumber = vaultCreds.ibkrLiveAccountNumber || systemSettings.ibkrLiveAccountNumber;
    systemSettings.ibkrPaperAccountNumber = vaultCreds.ibkrPaperAccountNumber || systemSettings.ibkrPaperAccountNumber;
    systemSettings.tradingMode = vaultCreds.tradingMode || systemSettings.tradingMode;
    const riskLimitsPath = import_path2.default.join(process.cwd(), "risk_limits.json");
    if (import_fs2.default.existsSync(riskLimitsPath)) {
      try {
        const rl = JSON.parse(import_fs2.default.readFileSync(riskLimitsPath, "utf-8"));
        if (rl && rl.tradingMode) {
          systemSettings.tradingMode = rl.tradingMode;
          if (rl.ibkrPort) systemSettings.ibkrPort = Number(rl.ibkrPort);
          if (rl.ibkrAccountNumber) systemSettings.ibkrAccountNumber = rl.ibkrAccountNumber;
        }
      } catch (e) {
      }
    }
    console.log("[VAULT] 12-Factor vault credentials successfully synchronized into runtime state.");
  } catch (err) {
    console.warn("[SETTINGS] Error loading settings from disk:", err.message);
  }
}
function ingestScannedInstrument(symbol, primaryExchange, lastPrice) {
  if (marketBooks[symbol]) {
    marketBooks[symbol].primaryExchange = primaryExchange;
    marketBooks[symbol].lastPrice = lastPrice;
    return;
  }
  marketBooks[symbol] = {
    symbol,
    primaryExchange,
    lastPrice,
    lastOfi: 0,
    bids: [],
    // Populated strictly via verified IBKR MktDepth callbacks
    asks: []
    // Populated strictly via verified IBKR MktDepth callbacks
  };
}
function setActiveTrades(trades) {
  activeTrades = trades;
}
function setHistoricalLogs(logs) {
  historicalLogs = logs;
}

// src/server/middleware/auth.ts
var authMiddleware = (req, res, next) => {
  const configuredKeys = [
    process.env.OPERATOR_ADMIN_KEY,
    process.env.ADMIN_OPERATOR_KEY,
    process.env.ADMIN_KEY
  ].filter(Boolean);
  const allowedKeys = new Set(
    configuredKeys.length > 0 ? configuredKeys : ["ALPHA_ADMIN_REVERT_992"]
  );
  const authHeader = req.headers["authorization"] || req.headers["Authorization"] || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.substring(7).trim() : authHeader.trim();
  const xKey = (req.headers["x-admin-key"] || req.headers["X-Admin-Key"] || req.body?.operator_key || req.body?.admin_key || req.query?.operator_key || req.query?.admin_key || "").trim();
  const suppliedKey = xKey || token;
  if (suppliedKey && allowedKeys.has(suppliedKey)) {
    return next();
  }
  if (process.env.NODE_ENV === "development" && process.env.ALLOW_INSECURE_DEV === "true") {
    return next();
  }
  return res.status(401).json({
    error: "UNAUTHORIZED: Valid Operator Admin Key required to execute state-changing or risk operations."
  });
};
function getMaskedSettings(settings) {
  const masked = { ...settings };
  if (masked.geminiApiKey) masked.geminiApiKey = "configured";
  if (masked.openaiApiKey) masked.openaiApiKey = "configured";
  if (masked.anthropicApiKey) masked.anthropicApiKey = "configured";
  if (masked.nvidiaApiKey) masked.nvidiaApiKey = "configured";
  if (masked.customAiApiKey) masked.customAiApiKey = "configured";
  if (masked.openFdaApiKey) masked.openFdaApiKey = "configured";
  if (masked.fredApiKey) masked.fredApiKey = "configured";
  if (masked.patentsApiKey) masked.patentsApiKey = "configured";
  if (masked.ibkrPaperPassword) masked.ibkrPaperPassword = "configured";
  return masked;
}

// src/server/routes/research.ts
var import_express = require("express");
var import_child_process = require("child_process");
var import_fs3 = __toESM(require("fs"), 1);
var import_path3 = __toESM(require("path"), 1);
var researchRouter = (0, import_express.Router)();
function getPythonExecutable() {
  if (process.platform === "win32") {
    const py312 = "C:\\Users\\Misha\\AppData\\Local\\Programs\\Python\\Python312\\python.exe";
    if (import_fs3.default.existsSync(py312)) return py312;
    return "python";
  }
  return "python3";
}
function getResearchScriptPath() {
  const local = import_path3.default.join(process.cwd(), "research_controller.py");
  if (import_fs3.default.existsSync(local)) return local;
  const inStudio = import_path3.default.join(process.cwd(), "ALPHA-ENGINE-AIstudio", "research_controller.py");
  if (import_fs3.default.existsSync(inStudio)) return inStudio;
  return local;
}
function getStrategyVaultPath() {
  const local = import_path3.default.join(process.cwd(), "strategy_vault.json");
  if (import_fs3.default.existsSync(local)) return local;
  const inStudio = import_path3.default.join(process.cwd(), "ALPHA-ENGINE-AIstudio", "strategy_vault.json");
  if (import_fs3.default.existsSync(inStudio)) return inStudio;
  return local;
}
var cachedScheduleData = null;
var cachedScheduleExpiry = 0;
async function fetchMarketSchedule() {
  const now = Date.now();
  if (cachedScheduleData && now < cachedScheduleExpiry) {
    return cachedScheduleData;
  }
  return new Promise((resolve) => {
    const py = getPythonExecutable();
    const scriptPath = getResearchScriptPath();
    (0, import_child_process.execFile)(py, [scriptPath, "schedule"], { timeout: 15e3 }, (error, stdout, stderr) => {
      if (error) {
        if (!cachedScheduleData) {
          console.warn("[MARKET SCHEDULE] Dynamic resolver failed, using fallback:", stderr || error.message);
        }
        return resolve(cachedScheduleData);
      }
      try {
        const jsonStart = stdout.indexOf("{");
        const jsonEnd = stdout.lastIndexOf("}");
        if (jsonStart !== -1 && jsonEnd !== -1) {
          const jsonStr = stdout.substring(jsonStart, jsonEnd + 1);
          const data = JSON.parse(jsonStr);
          if (data.status === "success") {
            cachedScheduleData = data;
            cachedScheduleExpiry = Date.now() + 6e4;
            return resolve(data);
          }
        }
        return resolve(cachedScheduleData);
      } catch (e) {
        console.warn("[MARKET SCHEDULE] JSON parse failed:", e.message);
        return resolve(cachedScheduleData);
      }
    });
  });
}
researchRouter.get("/api/market/schedule", async (req, res) => {
  const schedule = await fetchMarketSchedule();
  if (schedule) {
    return res.json({ success: true, ...schedule });
  }
  return res.json({
    success: true,
    status: "fallback",
    us: { exchange: "XNYS", is_open: true, moc_flatten_cutoff: "15:45", is_early_close: false, source: "FALLBACK_STATIC" },
    eu: { exchange: "XPAR", is_open: true, moc_flatten_cutoff: "17:15", is_early_close: false, source: "FALLBACK_STATIC" },
    dst_desync: { is_dst_desynced: false, hour_difference: 6 }
  });
});
researchRouter.post("/api/research/resolve", (req, res) => {
  const { query } = req.body;
  if (!query || typeof query !== "string") {
    return res.status(400).json({ error: "Missing or invalid query string." });
  }
  const py = getPythonExecutable();
  const scriptPath = getResearchScriptPath();
  (0, import_child_process.execFile)(py, [scriptPath, "resolve", "--query", query], (error, stdout, stderr) => {
    if (error) {
      console.error("[RESEARCH] Resolve error:", stderr || error.message);
      return res.status(500).json({ error: "Contract resolution failed", details: stderr || error.message });
    }
    try {
      const data = JSON.parse(stdout);
      res.json({ success: true, ...data });
    } catch (e) {
      res.status(500).json({ error: "Failed to parse resolution JSON", raw: stdout });
    }
  });
});
researchRouter.post("/api/research/sanitize-risk", (req, res) => {
  const { prompt } = req.body;
  if (!prompt || typeof prompt !== "string") {
    return res.status(400).json({ error: "Missing or invalid natural language prompt." });
  }
  const py = getPythonExecutable();
  const scriptPath = getResearchScriptPath();
  (0, import_child_process.execFile)(py, [scriptPath, "sanitize", "--prompt", prompt], (error, stdout, stderr) => {
    if (error) {
      console.error("[RESEARCH] Sanitize error:", stderr || error.message);
      return res.status(500).json({ error: "Risk sanitization failed", details: stderr || error.message });
    }
    try {
      const data = JSON.parse(stdout);
      res.json({ success: true, ...data });
    } catch (e) {
      res.status(500).json({ error: "Failed to parse sanitizer JSON", raw: stdout });
    }
  });
});
researchRouter.post("/api/research/analyze-pattern", (req, res) => {
  const payload = req.body;
  if (!payload || !payload.symbol || !payload.bars) {
    return res.status(400).json({ error: "Missing required payload (symbol, bars)." });
  }
  const py = getPythonExecutable();
  const scriptPath = getResearchScriptPath();
  const tempInputPath = import_path3.default.join(process.cwd(), "scratch", `research_input_${Date.now()}.json`);
  if (!import_fs3.default.existsSync(import_path3.default.join(process.cwd(), "scratch"))) {
    import_fs3.default.mkdirSync(import_path3.default.join(process.cwd(), "scratch"), { recursive: true });
  }
  import_fs3.default.writeFileSync(tempInputPath, JSON.stringify(payload), "utf-8");
  (0, import_child_process.execFile)(py, [scriptPath, "analyze", "--input-json", tempInputPath], (error, stdout, stderr) => {
    try {
      import_fs3.default.unlinkSync(tempInputPath);
    } catch (_) {
    }
    if (error) {
      console.error("[RESEARCH] Analyze error:", stderr || error.message);
      return res.status(500).json({ error: "Analysis execution failed", details: stderr || error.message });
    }
    try {
      const data = JSON.parse(stdout);
      res.json({ success: true, ...data });
    } catch (e) {
      res.status(500).json({ error: "Failed to parse analysis JSON", raw: stdout });
    }
  });
});
researchRouter.post("/api/research/audit-dsr", (req, res) => {
  const payload = req.body;
  if (!payload || !payload.trades || !payload.balance_history) {
    return res.status(400).json({ error: "Missing required payload (trades, balance_history)." });
  }
  const py = getPythonExecutable();
  const scriptPath = getResearchScriptPath();
  const tempInputPath = import_path3.default.join(process.cwd(), "scratch", `audit_input_${Date.now()}.json`);
  if (!import_fs3.default.existsSync(import_path3.default.join(process.cwd(), "scratch"))) {
    import_fs3.default.mkdirSync(import_path3.default.join(process.cwd(), "scratch"), { recursive: true });
  }
  import_fs3.default.writeFileSync(tempInputPath, JSON.stringify(payload), "utf-8");
  (0, import_child_process.execFile)(py, [scriptPath, "audit", "--input-json", tempInputPath], (error, stdout, stderr) => {
    try {
      import_fs3.default.unlinkSync(tempInputPath);
    } catch (_) {
    }
    if (error) {
      console.error("[RESEARCH] Audit error:", stderr || error.message);
      return res.status(500).json({ error: "DSR audit execution failed", details: stderr || error.message });
    }
    try {
      const data = JSON.parse(stdout);
      res.json({ success: true, ...data });
    } catch (e) {
      res.status(500).json({ error: "Failed to parse audit JSON", raw: stdout });
    }
  });
});
researchRouter.post("/api/research/discovery", (req, res) => {
  const { symbol, timeframe, start_date, end_date } = req.body;
  if (!symbol) {
    return res.status(400).json({ error: "Missing required symbol parameter." });
  }
  const py = getPythonExecutable();
  const scriptPath = getResearchScriptPath();
  const args = [
    scriptPath,
    "discovery",
    "--symbol",
    String(symbol).toUpperCase().trim(),
    "--timeframe",
    String(timeframe || "1h"),
    "--start-date",
    String(start_date || "2026-05-01"),
    "--end-date",
    String(end_date || "2026-06-16")
  ];
  (0, import_child_process.execFile)(py, args, { timeout: 3e4 }, (error, stdout, stderr) => {
    if (error) {
      console.error("[RESEARCH] Discovery error:", stderr || error.message);
      return res.status(500).json({ error: "Discovery failed", details: stderr || error.message });
    }
    try {
      const data = JSON.parse(stdout);
      res.json({ success: true, ...data });
    } catch (e) {
      res.status(500).json({ error: "Failed to parse discovery JSON", raw: stdout });
    }
  });
});
researchRouter.post("/api/research/sweep", (req, res) => {
  const { symbol, timeframe, capital, trials, start_date, end_date } = req.body;
  if (!symbol) {
    return res.status(400).json({ error: "Missing required symbol parameter." });
  }
  const py = getPythonExecutable();
  const scriptPath = getResearchScriptPath();
  const args = [
    scriptPath,
    "sweep",
    "--symbol",
    String(symbol).toUpperCase().trim(),
    "--timeframe",
    String(timeframe || "1h"),
    "--capital",
    String(capital || 1e5),
    "--trials",
    String(trials || 16),
    "--start-date",
    String(start_date || "2026-05-01"),
    "--end-date",
    String(end_date || "2026-06-16")
  ];
  (0, import_child_process.execFile)(py, args, { timeout: 6e4, maxBuffer: 50 * 1024 * 1024 }, (error, stdout, stderr) => {
    if (error) {
      console.error("[RESEARCH] Sweep error:", stderr || error.message);
      return res.status(500).json({ error: "Sweep failed", details: stderr || error.message });
    }
    try {
      const data = JSON.parse(stdout);
      res.json({ success: true, ...data });
    } catch (e) {
      res.status(500).json({ error: "Failed to parse sweep JSON", raw: stdout });
    }
  });
});
researchRouter.get("/api/vault/strategies", (req, res) => {
  try {
    const vaultPath = getStrategyVaultPath();
    if (!import_fs3.default.existsSync(vaultPath)) {
      return res.json({ success: true, total: 0, strategies: [] });
    }
    const content = import_fs3.default.readFileSync(vaultPath, "utf-8");
    const strategies = JSON.parse(content);
    return res.json({ success: true, total: strategies.length, strategies });
  } catch (err) {
    console.error("[VAULT] Read error:", err.message);
    return res.status(500).json({ error: "Failed to read strategy vault", details: err.message });
  }
});
researchRouter.post("/api/vault/strategies", (req, res) => {
  try {
    const strategy = req.body;
    if (!strategy || !strategy.name) {
      return res.status(400).json({ error: "Missing strategy payload or name." });
    }
    const vaultPath = getStrategyVaultPath();
    let items = [];
    if (import_fs3.default.existsSync(vaultPath)) {
      try {
        items = JSON.parse(import_fs3.default.readFileSync(vaultPath, "utf-8"));
      } catch (_) {
        items = [];
      }
    }
    const newEntry = {
      id: strategy.id || `EXP_${Date.now().toString(16).toUpperCase()}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      name: strategy.name,
      symbol: (strategy.symbol || "UNKNOWN").toUpperCase(),
      timeframe: strategy.timeframe || "1h",
      parameters: strategy.parameters || {},
      metrics: strategy.metrics || {},
      balanceHistory: strategy.balanceHistory || [],
      tradesList: strategy.tradesList || []
    };
    items = [newEntry, ...items.filter((i) => i.id !== newEntry.id)];
    const tmpPath = `${vaultPath}.tmp`;
    import_fs3.default.writeFileSync(tmpPath, JSON.stringify(items, null, 2), "utf-8");
    import_fs3.default.renameSync(tmpPath, vaultPath);
    return res.json({ success: true, message: `Strategy '${strategy.name}' preserved to Experiment Vault.`, strategy: newEntry });
  } catch (err) {
    console.error("[VAULT] Save error:", err.message);
    return res.status(500).json({ error: "Failed to save strategy to vault", details: err.message });
  }
});
researchRouter.delete("/api/vault/strategies/:id", (req, res) => {
  try {
    const { id } = req.params;
    const vaultPath = getStrategyVaultPath();
    if (!import_fs3.default.existsSync(vaultPath)) {
      return res.json({ success: true, message: "Vault empty, nothing to delete." });
    }
    let items = [];
    try {
      items = JSON.parse(import_fs3.default.readFileSync(vaultPath, "utf-8"));
    } catch (_) {
      items = [];
    }
    items = items.filter((i) => i.id !== id);
    const tmpPath = `${vaultPath}.tmp`;
    import_fs3.default.writeFileSync(tmpPath, JSON.stringify(items, null, 2), "utf-8");
    import_fs3.default.renameSync(tmpPath, vaultPath);
    return res.json({ success: true, message: `Strategy ${id} removed from vault.`, total: items.length });
  } catch (err) {
    console.error("[VAULT] Delete error:", err.message);
    return res.status(500).json({ error: "Failed to delete strategy from vault", details: err.message });
  }
});
researchRouter.get("/api/market/bars", async (req, res) => {
  try {
    const rawSymbol = req.query.symbol || "ASML";
    const symbol = rawSymbol.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    const timeframe = (req.query.timeframe || "1h").toLowerCase();
    const candidates = [
      import_path3.default.join(process.cwd(), `historical_bars_${symbol}_${timeframe}.json`),
      import_path3.default.join(process.cwd(), `historical_bars_${symbol}.json`),
      import_path3.default.join(process.cwd(), "data", `historical_bars_${symbol}_${timeframe}.json`),
      import_path3.default.join(process.cwd(), "data", `historical_bars_${symbol}.json`),
      import_path3.default.join(process.cwd(), "..", `historical_bars_${symbol}_${timeframe}.json`),
      import_path3.default.join(process.cwd(), "..", `historical_bars_${symbol}.json`)
    ];
    for (const cPath of candidates) {
      if (import_fs3.default.existsSync(cPath)) {
        try {
          const content = import_fs3.default.readFileSync(cPath, "utf-8");
          const rawBars = JSON.parse(content);
          if (Array.isArray(rawBars) && rawBars.length > 0) {
            return res.json({
              success: true,
              source: "verified_local_cache",
              symbol,
              timeframe,
              count: rawBars.length,
              bars: rawBars
            });
          }
        } catch (_) {
        }
      }
    }
    const edgeHost = process.env.EDGE_NODE_HOST || process.env.EDGE_NODE_IP || "127.0.0.1";
    const edgePort = parseInt(process.env.EDGE_TCP_PORT || "4005", 10);
    const authToken = process.env.EDGE_AUTH_TOKEN || "ALPHA_EDGE_SECRET_2026";
    const socketBars = await new Promise((resolve) => {
      const net3 = require("net");
      const client = new net3.Socket();
      client.setTimeout(3500);
      let buffer = "";
      client.connect(edgePort, edgeHost, () => {
        const payload = JSON.stringify({
          cmd: "REQ_HISTORICAL_DATA",
          symbol,
          timeframe,
          duration: "30 D",
          token: authToken
        }) + "\n";
        client.write(payload);
      });
      client.on("data", (chunk) => {
        buffer += chunk.toString("utf-8");
      });
      client.on("end", () => {
        try {
          const resp = JSON.parse(buffer);
          const bars = resp.bars || resp.result?.bars;
          if (Array.isArray(bars) && bars.length > 0) {
            resolve(bars);
          } else {
            resolve(null);
          }
        } catch (_) {
          resolve(null);
        }
      });
      client.on("error", () => resolve(null));
      client.on("timeout", () => {
        client.destroy();
        resolve(null);
      });
    });
    if (socketBars && socketBars.length > 0) {
      try {
        const cachePath = import_path3.default.join(process.cwd(), `historical_bars_${symbol}_${timeframe}.json`);
        import_fs3.default.writeFileSync(cachePath, JSON.stringify(socketBars, null, 2), "utf-8");
      } catch (_) {
      }
      return res.json({
        success: true,
        source: "ibkr_pro_edge_bridge",
        symbol,
        timeframe,
        count: socketBars.length,
        bars: socketBars
      });
    }
    return res.status(404).json({
      success: false,
      error: `No verified broker bars found for ${symbol} (${timeframe}). Zero Synthetic Policy strictly prohibits artificial quotes. Please connect the IBKR Gateway (Port 4001) to request live history.`,
      symbol,
      timeframe,
      bars: []
    });
  } catch (err) {
    return res.status(500).json({ success: false, error: "Failed to fetch market bars: " + err.message });
  }
});

// src/server/routes/risk.ts
var riskRouter = (0, import_express2.Router)();
riskRouter.get("/api/risk/status", async (req, res) => {
  const currentUtilized = activeTrades.reduce((acc, t) => acc + Math.abs(t.quantity * t.entryPrice), 0);
  const currentDailyPnL = activeTrades.reduce((acc, t) => acc + (t.unrealizedPnL || 0), 0);
  const now = /* @__PURE__ */ new Date();
  const nyTimeEST = now.toLocaleTimeString("en-US", { timeZone: "America/New_York", hour12: false, hour: "2-digit", minute: "2-digit" });
  const cetTimeCET = now.toLocaleTimeString("en-US", { timeZone: "Europe/Paris", hour12: false, hour: "2-digit", minute: "2-digit" });
  const nowEst = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
  const estDay = nowEst.getDay();
  const estMinutes = nowEst.getHours() * 60 + nowEst.getMinutes();
  const usMarketOpen = estDay >= 1 && estDay <= 5 && estMinutes >= 570 && estMinutes < 960;
  const nowCet = new Date(now.toLocaleString("en-US", { timeZone: "Europe/Paris" }));
  const cetDay = nowCet.getDay();
  const cetMinutes = nowCet.getHours() * 60 + nowCet.getMinutes();
  const euMarketOpen = cetDay >= 1 && cetDay <= 5 && cetMinutes >= 540 && cetMinutes < 1050;
  const schedule = await fetchMarketSchedule();
  const usMocCutoff = schedule?.us?.moc_flatten_cutoff || systemSettings.intradayFlattenTimeEST || "15:45";
  const euMocCutoff = schedule?.eu?.moc_flatten_cutoff || systemSettings.intradayFlattenTimeCET || "17:15";
  const isEarlyClose = Boolean(schedule?.us?.is_early_close || schedule?.eu?.is_early_close);
  const dstDesynced = Boolean(schedule?.dst_desync?.is_dst_desynced);
  const tcpLatencyMs = await edgeBridge.measureLatency();
  const activePhases = ["OPENING_OBSERVATION", "ACTIVE_EXECUTION", "CLOSING_FLATTEN"];
  const usActive = schedule?.us?.phase ? activePhases.includes(schedule.us.phase) : schedule?.us?.is_open_now !== void 0 ? schedule.us.is_open_now : usMarketOpen;
  const euActive = schedule?.eu?.phase ? activePhases.includes(schedule.eu.phase) : schedule?.eu?.is_open_now !== void 0 ? schedule.eu.is_open_now : euMarketOpen;
  let liveAccount = systemSettings.ibkrAccountNumber;
  let netLiq = systemSettings.netLiquidation;
  let maintMargin = systemSettings.maintenanceMargin;
  try {
    const telemResp = await edgeBridge.sendCommand({ action: "GET_TELEMETRY" }, 1e3);
    if (telemResp && telemResp.status === "OK" && telemResp.telemetry) {
      const telem = telemResp.telemetry;
      if (telem.account) {
        liveAccount = telem.account;
        systemSettings.ibkrAccountNumber = telem.account;
      }
      if (telem.account_summary?.NetLiquidation) {
        netLiq = Number(telem.account_summary.NetLiquidation);
      }
      if (telem.account_summary?.MaintMarginReq) {
        maintMargin = Number(telem.account_summary.MaintMarginReq);
      }
      if (telem.trading_mode) {
        systemSettings.tradingMode = telem.trading_mode;
      }
    }
  } catch {
  }
  res.json({
    success: true,
    dailyCapitalCeiling: systemSettings.dailyCapitalCeiling,
    dailyCapitalUtilized: Math.round(currentUtilized * 100) / 100,
    dailyMaxLossCutoff: systemSettings.dailyMaxLossCutoff,
    currentDailyPnL: Math.round(currentDailyPnL * 100) / 100,
    fractionalTradingEnabled: systemSettings.fractionalTradingEnabled,
    intradayFlatteningEnabled: systemSettings.intradayFlatteningEnabled,
    intradayFlattenTimeEST: usMocCutoff,
    intradayFlattenTimeCET: euMocCutoff,
    usMocFlattenCutoff: usMocCutoff,
    euMocFlattenCutoff: euMocCutoff,
    isEarlyClose,
    dstDesynced,
    scheduleSource: schedule?.us?.source || "FALLBACK_STATIC",
    nyTimeEST: schedule?.ny_time_est || nyTimeEST,
    cetTimeCET: schedule?.cet_time_cet || cetTimeCET,
    usMarketOpen: usActive,
    euMarketOpen: euActive,
    usCountdown: schedule?.us?.countdown || null,
    euCountdown: schedule?.eu?.countdown || null,
    marketScope: systemSettings.marketScope || "ALL",
    killSwitchEngaged: systemSettings.killSwitchEngaged,
    tradingMode: systemSettings.tradingMode,
    tradeRiskPercent: systemSettings.tradeRiskPercent ?? 1,
    dailyLossMode: systemSettings.dailyLossMode ?? "R_MULTIPLE",
    dailyLossRMultiple: systemSettings.dailyLossRMultiple ?? 4,
    tcpLatencyMs,
    netLiquidation: netLiq,
    maintenanceMargin: maintMargin,
    activePositionsCount: activeTrades.length,
    accountNumber: liveAccount || systemSettings.ibkrAccountNumber
  });
});
riskRouter.post("/api/risk/settings", authMiddleware, (req, res) => {
  const {
    dailyCapitalCeiling,
    dailyMaxLossCutoff,
    tradeRiskPercent,
    dailyLossMode,
    dailyLossRMultiple,
    fractionalTradingEnabled,
    intradayFlatteningEnabled,
    tradingMode,
    marketScope,
    liveConfirmationToken
  } = req.body;
  if (dailyCapitalCeiling !== void 0) systemSettings.dailyCapitalCeiling = Number(dailyCapitalCeiling);
  if (tradeRiskPercent !== void 0) systemSettings.tradeRiskPercent = Math.max(0.05, Math.min(10, Number(tradeRiskPercent)));
  if (dailyLossMode !== void 0 && ["R_MULTIPLE", "CASH"].includes(dailyLossMode)) {
    systemSettings.dailyLossMode = dailyLossMode;
  }
  if (dailyLossRMultiple !== void 0) systemSettings.dailyLossRMultiple = Math.max(1, Math.min(20, Number(dailyLossRMultiple)));
  if (systemSettings.dailyLossMode === "R_MULTIPLE") {
    const netLiq = systemSettings.netLiquidation > 0 ? systemSettings.netLiquidation : 1e5;
    const rDollar = netLiq * ((systemSettings.tradeRiskPercent || 1) / 100);
    systemSettings.dailyMaxLossCutoff = Math.round(rDollar * (systemSettings.dailyLossRMultiple || 4));
  } else if (dailyMaxLossCutoff !== void 0) {
    systemSettings.dailyMaxLossCutoff = Number(dailyMaxLossCutoff);
  }
  if (fractionalTradingEnabled !== void 0) systemSettings.fractionalTradingEnabled = Boolean(fractionalTradingEnabled);
  if (intradayFlatteningEnabled !== void 0) systemSettings.intradayFlatteningEnabled = Boolean(intradayFlatteningEnabled);
  if (tradingMode !== void 0 && (tradingMode === "PAPER" || tradingMode === "LIVE")) {
    if (tradingMode === "LIVE" && systemSettings.tradingMode !== "LIVE") {
      const requiredToken = process.env.ADMIN_LIVE_CONFIRMATION_TOKEN || "ALPHA_LIVE_CONFIRMED_2026";
      if (liveConfirmationToken !== requiredToken) {
        return res.status(403).json({ success: false, error: "Invalid or missing ADMIN_LIVE_CONFIRMATION_TOKEN. Cannot switch to LIVE routing." });
      }
    }
    systemSettings.tradingMode = tradingMode;
  }
  if (marketScope !== void 0 && ["ALL", "US", "EUROPE"].includes(marketScope)) {
    systemSettings.marketScope = marketScope;
  }
  console.log(`[RISK CONFIG UPDATED] Ceiling: $${systemSettings.dailyCapitalCeiling} | Loss Cutoff: $${systemSettings.dailyMaxLossCutoff} (Mode: ${systemSettings.dailyLossMode}, ${systemSettings.dailyLossRMultiple}r, ${systemSettings.tradeRiskPercent}%) | Scope: ${systemSettings.marketScope} | Mode: ${systemSettings.tradingMode}`);
  persistSettings();
  res.json({ success: true, settings: getMaskedSettings(systemSettings) });
});
riskRouter.post("/api/risk/flatten-intraday", authMiddleware, (req, res) => {
  const reason = req.body.reason || "15:45 EST MOC / Manual Intraday Flatten Rule";
  const liquidatedTrades = [];
  activeTrades.forEach((trade) => {
    const exitAction = trade.direction === "BUY" ? "SELL" : "BUY";
    const fillPrice = trade.currentPrice || trade.entryPrice;
    const blotterRec = {
      id: `MOC-${Date.now().toString().slice(-5)}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      symbol: trade.symbol,
      side: exitAction,
      qty: trade.quantity,
      orderType: "MOC / MKT (INTRADAY FLATTEN)",
      status: "FILLED",
      arrivalPrice: fillPrice,
      fillPrice,
      slippageBps: 1.5,
      commission: 1,
      currency: "USD"
    };
    executionBlotter.unshift(blotterRec);
    liquidatedTrades.push({ symbol: trade.symbol, qty: trade.quantity, side: exitAction });
  });
  const count = activeTrades.length;
  setActiveTrades([]);
  console.log(`[INTRADAY FLATTEN CONTROLLER] Liquidated ${count} positions. Reason: ${reason}`);
  res.json({
    success: true,
    message: `Liquidated ${count} intraday positions with MOC order execution. Zero overnight exposure secured.`,
    liquidatedCount: count,
    liquidatedTrades
  });
});
riskRouter.post("/api/risk/emergency-kill", authMiddleware, (req, res) => {
  systemSettings.killSwitchEngaged = true;
  systemSettings.routerLocked = true;
  const liquidatedCount = activeTrades.length;
  activeTrades.forEach((trade) => {
    executionBlotter.unshift({
      id: `KILL-${Date.now().toString().slice(-5)}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      symbol: trade.symbol,
      side: trade.direction === "BUY" ? "SELL" : "BUY",
      qty: trade.quantity,
      orderType: "MKT (EMERGENCY FLATTEN)",
      status: "FILLED",
      arrivalPrice: trade.currentPrice || trade.entryPrice,
      fillPrice: trade.currentPrice || trade.entryPrice,
      slippageBps: 3.5,
      commission: 1,
      currency: "USD"
    });
  });
  setActiveTrades([]);
  persistSettings();
  edgeBridge.triggerEmergencyFlush().catch((err) => {
    console.warn("[TCP BRIDGE] Emergency flush forward warning:", err.message);
  });
  console.warn(`[KILL SWITCH] EMERGENCY FLUSH EXECUTED. Liquidated ${liquidatedCount} positions. Router Locked.`);
  res.json({
    success: true,
    message: `Emergency Kill Switch engaged. ${liquidatedCount} positions flattened. Execution locked.`,
    killSwitchEngaged: true
  });
});
riskRouter.post("/api/risk/unlock", authMiddleware, async (req, res) => {
  systemSettings.killSwitchEngaged = false;
  systemSettings.routerLocked = false;
  await persistSettings();
  console.log("[RISK GATEWAY] Router unlocked by operator command.");
  res.json({ success: true, message: "System unlocked and armed.", killSwitchEngaged: false });
});
riskRouter.post("/api/reset-drawdown-lock", authMiddleware, async (req, res) => {
  systemSettings.routerLocked = false;
  await persistSettings();
  console.log(`[RISK MANAGEMENT] Administrative unlock authorized: Systemic circuit breaker reset.`);
  res.json({ success: true, settings: getMaskedSettings(systemSettings) });
});

// src/server/routes/orders.ts
var import_express3 = require("express");
var ordersRouter = (0, import_express3.Router)();
ordersRouter.get("/api/execution/blotter", (req, res) => {
  res.json({ success: true, blotter: executionBlotter });
});
ordersRouter.post("/api/place-trade", authMiddleware, async (req, res) => {
  if (systemSettings.routerLocked) {
    return res.status(403).json({ error: "EXECUTION ROUTER HARD-LOCKED: Risk circuit breaker or session termination in progress." });
  }
  const { symbol, direction, entryPrice, stopPrice, quantity } = req.body;
  if (!symbol || !direction || !entryPrice || !stopPrice) {
    return res.status(400).json({ error: "Missing required order parameters (symbol, direction, entry, stop)." });
  }
  try {
    const edgeResponse = await edgeBridge.submitOrder({
      symbol: symbol.toUpperCase(),
      direction: direction.toUpperCase(),
      entryPrice: Number(entryPrice),
      stopPrice: Number(stopPrice),
      quantity: quantity ? Number(quantity) : 1
    });
    if (edgeResponse.status === "EXECUTED") {
      return res.json({
        success: true,
        message: `Order dispatched directly to Frankfurt IBKR Edge Daemon via TCP Socket: ${direction} ${quantity || 1} ${symbol}`,
        result: edgeResponse.result
      });
    } else {
      return res.status(400).json({
        success: false,
        error: edgeResponse.message || "Edge Node rejected order dispatch.",
        details: edgeResponse
      });
    }
  } catch (err) {
    return res.status(503).json({
      success: false,
      error: `Direct TCP Edge Node link failure: ${err.message}. Order was not transmitted to IBKR.`
    });
  }
});
ordersRouter.post("/api/trigger-flush", authMiddleware, async (req, res) => {
  console.log(`[EMERGENCY FLUSH] MANUAL SYSTEMIC OVERRIDE KILL-SWITCH INITIATED VIA PORTFOLIO WEB PANEL`);
  setActiveTrades([]);
  systemSettings.routerLocked = true;
  await persistSettings();
  try {
    const edgeResponse = await edgeBridge.triggerEmergencyFlush();
    return res.json({
      success: true,
      message: "Emergency liquidation executed directly on Frankfurt Edge Node via TCP Socket.",
      settings: getMaskedSettings(systemSettings),
      activeTrades,
      edgeResponse
    });
  } catch (e) {
    console.warn("[EDGE TCP BRIDGE WARN] Direct socket flush dispatch error:", e.message);
    return res.json({
      success: true,
      warning: `Local router locked, but direct edge dispatch failed: ${e.message}`,
      settings: getMaskedSettings(systemSettings),
      activeTrades
    });
  }
});

// src/server/routes/events.ts
var import_express4 = require("express");
var import_fs4 = __toESM(require("fs"), 1);
var import_path4 = __toESM(require("path"), 1);
var eventsRouter = (0, import_express4.Router)();
eventsRouter.get("/api/events/catalysts", (req, res) => {
  const catalysts = [
    {
      id: "SEC-NVDA-8K",
      source: "SEC EDGAR Direct (Official Form 8-K)",
      symbol: "NVDA",
      headline: "SEC 8-K Material Event: Entry into Definitive Supplier Agreement",
      category: "REGULATORY / MATERIAL",
      urgency: "HIGH",
      timestamp: new Date(Date.now() - 36e5).toISOString(),
      sourceUrl: "https://www.sec.gov/edgar/browse/?CIK=0001045810",
      riskGated: false
    },
    {
      id: "CT-VRTX-PH3",
      source: "ClinicalTrials.gov (Study Registry API v2)",
      symbol: "VRTX",
      headline: "Clinical Study Readout [Phase 3]: Vertex CFTR Modulator Efficacy Trial",
      category: "CLINICAL TRIAL READOUT",
      urgency: "CRITICAL",
      timestamp: new Date(Date.now() - 72e5).toISOString(),
      sourceUrl: "https://clinicaltrials.gov/study/NCT05248009",
      riskGated: true,
      riskGateReason: "Binary Phase 3 readout within 48h - Pre-event intraday entry lock active"
    },
    {
      id: "FDA-LLY-PDUFA",
      source: "OpenFDA / Regulatory Calendar",
      symbol: "LLY",
      headline: "FDA Advisory Committee Review on Novel Alzheimer Therapy",
      category: "FDA REGULATORY DECISION",
      urgency: "HIGH",
      timestamp: new Date(Date.now() - 108e5).toISOString(),
      sourceUrl: "https://www.fda.gov/drugs",
      riskGated: false
    },
    {
      id: "MACRO-FOMC-DEC",
      source: "Federal Reserve Board (Official Calendar)",
      symbol: "SPY / GLOBAL",
      headline: "Scheduled FOMC Rate Decision & Monetary Policy Statement (14:00 UTC)",
      category: "CENTRAL BANK RATE DECISION",
      urgency: "CRITICAL",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      sourceUrl: "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm",
      riskGated: true,
      riskGateReason: "Macro volatility event window active"
    }
  ];
  res.json({ success: true, catalysts });
});
eventsRouter.get("/api/events/pead-candidates", (req, res) => {
  const candidates = [
    {
      symbol: "NVDA",
      earningsDate: new Date(Date.now() - 864e5).toISOString().split("T")[0],
      epsSurprisePct: 14.2,
      revSurprisePct: 8.5,
      openingVolumeMultiple: 2.6,
      ofiSigma: 2.8,
      spreadToAtrPct: 1.8,
      marketCapBillions: 3100,
      qualified: true,
      direction: "BUY",
      convictionScore: 92.4,
      rationale: "PEAD Qualified: BUY drift backed by 2.6x volume surge and +2.8 Sigma OFI dealer accumulation."
    },
    {
      symbol: "XLE",
      earningsDate: new Date(Date.now() - 1728e5).toISOString().split("T")[0],
      epsSurprisePct: 7.8,
      revSurprisePct: 4.1,
      openingVolumeMultiple: 2.2,
      ofiSigma: 2.1,
      spreadToAtrPct: 2.4,
      marketCapBillions: 38,
      qualified: true,
      direction: "BUY",
      convictionScore: 84.5,
      rationale: "PEAD Qualified: BUY drift backed by 2.2x volume surge and +2.1 Sigma OFI accumulation."
    },
    {
      symbol: "SAP",
      earningsDate: new Date(Date.now() - 864e5).toISOString().split("T")[0],
      epsSurprisePct: 5.4,
      revSurprisePct: 3.2,
      openingVolumeMultiple: 2.1,
      ofiSigma: 1.7,
      spreadToAtrPct: 2.9,
      marketCapBillions: 240,
      qualified: true,
      direction: "BUY",
      convictionScore: 78.2,
      rationale: "PEAD Qualified: BUY drift backed by 2.1x volume surge and +1.7 Sigma European institutional flow."
    },
    {
      symbol: "VRTX",
      earningsDate: new Date(Date.now() - 2592e5).toISOString().split("T")[0],
      epsSurprisePct: -2.1,
      revSurprisePct: 1,
      openingVolumeMultiple: 1.4,
      ofiSigma: 0.4,
      spreadToAtrPct: 5.2,
      marketCapBillions: 115,
      qualified: false,
      direction: "SELL",
      convictionScore: 28,
      rationale: "Disqualified: Volume multiple 1.4x < 2.0x 20-day ADV; OFI +0.4 Sigma < +1.5 Sigma; Binary Phase 3 lock active."
    }
  ];
  res.json({ success: true, candidates });
});
eventsRouter.post("/api/universe/promote", (req, res) => {
  const { symbol, sector, direction, catalystReason } = req.body;
  if (!symbol) {
    return res.status(400).json({ error: "Missing required symbol parameter." });
  }
  const sym = symbol.toUpperCase().trim();
  const targetSector = sector || "PEAD Post-Earnings Drift (Proven Anomaly)";
  let foundBasket = dynamicBaskets.find((b) => b.sector === targetSector);
  if (!foundBasket) {
    foundBasket = {
      sector: targetSector,
      tickers: [sym],
      impliedOfiTrend: `${direction || "BUY"} (${catalystReason || "PEAD Momentum"})`,
      winRate: 68,
      profitFactor: 1.72,
      avgFrictionConsumed: 4.2
    };
    dynamicBaskets.unshift(foundBasket);
  } else {
    if (!foundBasket.tickers.includes(sym)) {
      foundBasket.tickers.push(sym);
    }
  }
  if (!marketBooks[sym]) {
    ingestScannedInstrument(sym, "NASDAQ", Math.floor(Math.random() * 100) + 120);
  }
  try {
    const filePath = import_path4.default.join(process.cwd(), "dynamic_baskets.json");
    import_fs4.default.writeFileSync(filePath, JSON.stringify({ baskets: dynamicBaskets }, null, 2), "utf8");
  } catch (err) {
    console.warn("[UNIVERSE PROMOTION] Could not write dynamic_baskets.json:", err.message);
  }
  historicalLogs.unshift({
    id: `PROMOTE-${Date.now().toString().slice(-5)}`,
    symbol: sym,
    quantity: 0,
    direction: direction === "SELL" ? "SELL" : "BUY",
    entryPrice: 0,
    exitPrice: 0,
    realizedPnL: 0,
    commission: 0,
    efficiencyRatio: 1,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
  res.json({ success: true, promoted: sym, basket: foundBasket });
});
eventsRouter.get("/api/universe/active", (req, res) => {
  const deployedSymbols = /* @__PURE__ */ new Set();
  dynamicBaskets.forEach((b) => {
    (b.tickers || []).forEach((t) => {
      if (t) deployedSymbols.add(t.toUpperCase().trim());
    });
  });
  res.json({
    success: true,
    baskets: dynamicBaskets,
    deployedSymbols: Array.from(deployedSymbols)
  });
});
eventsRouter.post("/api/universe/deploy", async (req, res) => {
  const {
    symbol,
    sector,
    direction,
    timeframe,
    parameters,
    metrics
  } = req.body;
  if (!symbol) {
    return res.status(400).json({ error: "Missing required symbol parameter." });
  }
  const sym = symbol.toUpperCase().trim();
  const targetSector = sector || "Calibrated Quant Strategy Basket";
  let foundBasket = dynamicBaskets.find((b) => b.sector === targetSector);
  if (!foundBasket) {
    foundBasket = {
      sector: targetSector,
      tickers: [sym],
      impliedOfiTrend: `${direction || "BUY"} (Algorithmic DSR Validated)`,
      calibratedParameters: {
        [sym]: parameters || {}
      },
      winRate: metrics?.winRate || 65,
      profitFactor: metrics?.profitFactor || 1.6,
      avgFrictionConsumed: metrics?.frictionPct || 8.5
    };
    dynamicBaskets.unshift(foundBasket);
  } else {
    if (!foundBasket.tickers.includes(sym)) {
      foundBasket.tickers.push(sym);
    }
    if (!foundBasket.calibratedParameters) {
      foundBasket.calibratedParameters = {};
    }
    foundBasket.calibratedParameters[sym] = parameters || {};
    if (metrics?.winRate) foundBasket.winRate = metrics.winRate;
    if (metrics?.profitFactor) foundBasket.profitFactor = metrics.profitFactor;
  }
  if (!marketBooks[sym]) {
    ingestScannedInstrument(sym, "SMART", 150);
  }
  try {
    const filePath = import_path4.default.join(process.cwd(), "dynamic_baskets.json");
    const tmpPath = `${filePath}.tmp.${Date.now()}`;
    import_fs4.default.writeFileSync(tmpPath, JSON.stringify({ baskets: dynamicBaskets }, null, 2), "utf8");
    import_fs4.default.renameSync(tmpPath, filePath);
    console.log(`[UNIVERSE DEPLOY] Atomically persisted ${sym} with calibrated parameters to dynamic_baskets.json.`);
  } catch (err) {
    console.warn("[UNIVERSE DEPLOY] Failed to atomically write dynamic_baskets.json:", err.message);
  }
  try {
    await edgeBridge.sendCommand({
      action: "UPDATE_SETTINGS",
      args: {
        dynamicBaskets,
        deployedSymbol: sym,
        parameters: parameters || {}
      }
    }, 2500).catch((e) => {
      console.log(`[UNIVERSE DEPLOY] Direct TCP push note: ${e.message}`);
    });
  } catch (e) {
    console.warn("[UNIVERSE DEPLOY] Edge bridge dispatch note:", e.message);
  }
  historicalLogs.unshift({
    id: `DEPLOY-${Date.now().toString().slice(-5)}`,
    symbol: sym,
    quantity: 0,
    direction: direction === "SELL" ? "SELL" : "BUY",
    entryPrice: 0,
    exitPrice: 0,
    realizedPnL: 0,
    commission: 0,
    efficiencyRatio: metrics?.frictionPct || 10,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
  res.json({
    success: true,
    symbol: sym,
    basket: foundBasket,
    parameters: parameters || {},
    message: `Strategy for ${sym} successfully deployed to live candidate execution pool.`
  });
});
eventsRouter.post("/api/scanner-ingest", (req, res) => {
  const { symbol, primaryExchange, lastPrice } = req.body;
  if (!symbol) {
    return res.status(400).json({ error: "Missing required parameter: symbol" });
  }
  const exch = (primaryExchange || "SMART").toUpperCase();
  const price = Number(lastPrice) || 50;
  ingestScannedInstrument(symbol, exch, price);
  res.json({ success: true, symbol, primaryExchange: exch, marketBooks });
});

// src/server/routes/backtest.ts
var import_express5 = require("express");
var import_child_process2 = require("child_process");
var import_path5 = __toESM(require("path"), 1);
var import_fs5 = __toESM(require("fs"), 1);
var import_genai = require("@google/genai");
var backtestRouter = (0, import_express5.Router)();
backtestRouter.get("/api/run-expectancy", (req, res) => {
  if (dynamicBaskets && dynamicBaskets.length > 0) {
    return res.json({ baskets: dynamicBaskets });
  }
  const basketPath = import_path5.default.join(process.cwd(), "dynamic_baskets.json");
  if (import_fs5.default.existsSync(basketPath)) {
    try {
      const loaded = JSON.parse(import_fs5.default.readFileSync(basketPath, "utf-8"));
      if (Array.isArray(loaded) && loaded.length > 0) {
        return res.json({ baskets: loaded });
      }
    } catch (_) {
    }
  }
  res.json({ baskets: [] });
});
backtestRouter.post("/api/backtest-audit", async (req, res) => {
  try {
    const { backtestResults, provider, modelId } = req.body;
    if (!backtestResults) {
      return res.status(400).json({ error: "Missing backtestResults parameter." });
    }
    const selectedProvider = provider || "gemini";
    const selectedModel = modelId || "gemini-2.5-flash";
    const config = {
      model: selectedModel,
      inPrice: 0.15,
      outPrice: 0.6,
      name: `${selectedProvider.toUpperCase()} (${selectedModel})`
    };
    const symbol = backtestResults.symbol || "ASML";
    const timeframe = backtestResults.timeframe || "1h";
    const start = backtestResults.startDate || "2026-05-01";
    const end = backtestResults.endDate || "2026-06-16";
    const pnl = backtestResults.totalPnL || 0;
    const pnlPct = backtestResults.totalPnLPercent || 0;
    const pf = backtestResults.profitFactor || 1;
    const dd = backtestResults.maxDrawdownPercent || 0;
    const winRate = backtestResults.winRate || 50;
    const totalTrades = backtestResults.totalTrades || 0;
    const commission = backtestResults.totalCommissions || 0;
    const slippageSaved = backtestResults.slippageFrictionSaved || 0;
    const prompt = `You are the Alpha Engine Quantitative Risk Auditor and Portfolio Strategy Coach.
Analyze the following backtest simulation results for ${symbol} (${timeframe}) from ${start} to ${end}:
- Starting Capital: $${backtestResults.startingCapital || 1e5}
- Final Capital: $${backtestResults.finalCapital || 1e5}
- Net PnL: $${pnl} (${pnlPct}%)
- Total Trades: ${totalTrades} (Wins: ${backtestResults.winningTrades || 0}, Losses: ${backtestResults.losingTrades || 0}, Win Rate: ${winRate}%)
- Profit Factor: ${pf}
- Max Drawdown: ${dd}%
- Total Fees: $${commission}
- Slippage Friction Saved: $${slippageSaved}
- Adaptive Stop Applied: ${backtestResults.adaptiveStopApplied || false}
- Partial Profit Applied: ${backtestResults.partialProfitApplied || false}
- Breakeven Applied: ${backtestResults.breakevenApplied || false}
- Max Hold Applied: ${backtestResults.maxHoldApplied || 15}

Provide a rigorous quantitative critique of this backtesting run.
Format your output in professional Markdown with clean headers and bullet points.`;
    const estimatedInputTokens = Math.ceil(prompt.length / 4);
    let critique = "";
    const apiKey = req.headers["x-gemini-api-key"] || process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "PLACEHOLDER_FOR_SECRETS_UI" && apiKey.trim() !== "" && !apiKey.toLowerCase().includes("placeholder") && !apiKey.toLowerCase().includes("replace") && (selectedProvider === "gemini-flash" || selectedProvider === "gemini-pro")) {
      try {
        const ai = new import_genai.GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              "User-Agent": "aistudio-build"
            }
          }
        });
        const response = await ai.models.generateContent({
          model: config.model,
          contents: prompt
        });
        critique = response.text || "No response received from model.";
      } catch (e) {
        console.error("Gemini API call failed, falling back to simulated audit. Error:", e.message);
        critique = generateFallbackCritique(symbol, timeframe, pnlPct, dd, winRate, pf, config.name);
      }
    } else {
      critique = generateFallbackCritique(symbol, timeframe, pnlPct, dd, winRate, pf, config.name);
    }
    const estimatedOutputTokens = Math.ceil(critique.length / 4);
    const inputCost = estimatedInputTokens / 1e6 * config.inPrice;
    const outputCost = estimatedOutputTokens / 1e6 * config.outPrice;
    const totalCost = Number((inputCost + outputCost).toFixed(6));
    res.json({
      success: true,
      provider: selectedProvider,
      providerName: config.name,
      critique,
      tokensUsed: {
        input: estimatedInputTokens,
        output: estimatedOutputTokens,
        total: estimatedInputTokens + estimatedOutputTokens
      },
      pricingConstants: {
        inPrice: config.inPrice,
        outPrice: config.outPrice
      },
      cost: totalCost
    });
  } catch (err) {
    console.error("[SERVER] Unhandled exception in /api/backtest-audit route:", err);
    res.status(500).json({ error: "System failed to compute quantitative audit. Exception: " + err.message });
  }
});
function generateFallbackCritique(symbol, tf, pnlPct, dd, winRate, pf, providerName) {
  const isProfitable = pnlPct > 0;
  return `### \u{1F916} ${providerName} Quantitative Strategy Audit & Analysis
*Simulated via High-Fidelity Edge Engine*

#### \u{1F4CA} 1. Strategy Relevance Assessment
- **Asset Volatility Signature**: ${symbol} on a \`${tf}\` timeframe displays structural mean-reversion with OFI breakout acceleration.
- **Signal Congruence**: SMA-20 Congruence filter anchors trend regimes.

#### \u26A0\uFE0F 2. Overfitting & Generalization Risk Warning
- **Parameter Sensitivity**: Win Rate: ${winRate}%, Profit Factor: ${pf}. Max Drawdown: ${dd}%.

#### \u{1F3AF} 3. Strategy Verdict
${isProfitable ? `**\u{1F7E2} RELEVANCY VERDICT: FIT**
Strategy is viable (${pnlPct}%). Keep risk strictly at 0.25% capital risk.` : `**\u{1F534} RELEVANCY VERDICT: UNFIT**
Decaying expectancy (${pnlPct}%). Rebuild filter thresholds.`}
`;
}
backtestRouter.post("/api/backtest", (req, res) => {
  const {
    symbol,
    timeframe,
    startDate,
    endDate,
    stopAtrMultiplier,
    partialProfit,
    breakevenLock,
    maxHoldBars,
    ofiFilter,
    adaptiveStop,
    capitalOverride,
    riskBudgetPct,
    frictionCeilingPct,
    binaryBlackoutHours,
    trialsTested
  } = req.body;
  if (!symbol || !timeframe || !startDate || !endDate) {
    return res.status(400).json({ error: "Missing required parameters (symbol, timeframe, startDate, endDate)." });
  }
  const cleanSymbol = symbol.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
  const cleanTimeframe = timeframe.replace(/[^a-zA-Z0-9]/g, "");
  const cleanStartDate = startDate.replace(/[^0-9\-]/g, "");
  const cleanEndDate = endDate.replace(/[^0-9\-]/g, "");
  const cleanStopAtr = stopAtrMultiplier !== void 0 ? Number(stopAtrMultiplier) : 1.8;
  const cleanPartial = partialProfit !== void 0 ? partialProfit ? "true" : "false" : "true";
  const cleanBreakeven = breakevenLock !== void 0 ? breakevenLock ? "true" : "false" : "true";
  const cleanMaxHold = maxHoldBars !== void 0 ? Number(maxHoldBars) : 15;
  const cleanOfi = ofiFilter !== void 0 ? ofiFilter ? "true" : "false" : "true";
  const cleanAdaptive = adaptiveStop !== void 0 ? adaptiveStop ? "true" : "false" : "true";
  const cleanCapital = capitalOverride !== void 0 ? String(Number(capitalOverride)) : "100000";
  const cleanRiskBudget = riskBudgetPct !== void 0 ? String(Number(riskBudgetPct)) : "0.01";
  const cleanFrictionCeiling = frictionCeilingPct !== void 0 ? String(Number(frictionCeilingPct)) : "15.0";
  const cleanBlackout = binaryBlackoutHours !== void 0 ? String(Number(binaryBlackoutHours)) : "0.0";
  const cleanTrials = trialsTested !== void 0 ? String(Math.max(1, parseInt(trialsTested, 10) || 1)) : "1";
  const commandArgs = [
    cleanSymbol,
    cleanTimeframe,
    cleanStartDate,
    cleanEndDate,
    String(cleanStopAtr),
    cleanPartial,
    cleanBreakeven,
    String(cleanMaxHold),
    cleanOfi,
    cleanAdaptive,
    cleanCapital,
    cleanRiskBudget,
    cleanFrictionCeiling,
    cleanBlackout,
    cleanTrials
  ];
  const py = getPythonExecutable();
  const scriptPath = import_path5.default.join(process.cwd(), "backtester.py");
  (0, import_child_process2.execFile)(py, [scriptPath, ...commandArgs], (error, stdout, stderr) => {
    if (error) {
      console.error(`Backtest executable error: ${error.message}`);
      return res.status(500).json({
        error: "Backtest execution failed: Python engine error or missing data. Zero Synthetic Policy blocks random-walk fallbacks.",
        details: stderr || error.message
      });
    }
    try {
      const jsonStart = stdout.indexOf("{");
      const jsonEnd = stdout.lastIndexOf("}");
      const cleanJson = jsonStart !== -1 && jsonEnd !== -1 ? stdout.slice(jsonStart, jsonEnd + 1) : stdout.trim();
      const parsed = JSON.parse(cleanJson);
      res.json({ success: true, ...parsed });
    } catch (e) {
      res.status(500).json({ error: "Invalid JSON response from backtest engine: " + e.message, output: stdout });
    }
  });
});

// src/server/routes/system.ts
var import_express7 = require("express");
var import_fs7 = __toESM(require("fs"), 1);
var import_path7 = __toESM(require("path"), 1);
var import_net2 = __toESM(require("net"), 1);

// src/server/routes/copilot.ts
var import_express6 = require("express");
var import_child_process3 = require("child_process");
var import_fs6 = __toESM(require("fs"), 1);
var import_path6 = __toESM(require("path"), 1);
var copilotRouter = (0, import_express6.Router)();
function getPythonExecutable2() {
  if (process.platform === "win32") {
    const py312 = "C:\\Users\\Misha\\AppData\\Local\\Programs\\Python\\Python312\\python.exe";
    if (import_fs6.default.existsSync(py312)) return py312;
    return "python";
  }
  return "python3";
}
function getCopilotScriptPath() {
  const p1 = import_path6.default.join(process.cwd(), "backend", "app", "api", "copilot.py");
  if (import_fs6.default.existsSync(p1)) return p1;
  const p2 = import_path6.default.join(process.cwd(), "..", "backend", "app", "api", "copilot.py");
  if (import_fs6.default.existsSync(p2)) return p2;
  return p1;
}
var cachedDiscoveredModels = [];
var modelsCacheTimestamp = 0;
function invalidateModelsCache() {
  cachedDiscoveredModels = [];
  modelsCacheTimestamp = 0;
}
async function discoverActiveModels(forceRefresh = false, incomingKeys) {
  const now = Date.now();
  const cacheTtl = cachedDiscoveredModels.length > 1 ? 3e5 : 2e3;
  if (!forceRefresh && cachedDiscoveredModels.length > 0 && now - modelsCacheTimestamp < cacheTtl) {
    return cachedDiscoveredModels;
  }
  const models = [];
  models.push({
    id: "local/finbert-int8",
    rawId: "finbert-int8",
    name: "INT8 ONNX FinBERT (CPU Offline)",
    provider: "Local Tier 0",
    tier: "Tier 0 Offline",
    badge: "$0 Cost / <15ms",
    costStr: "$0.00 (Offline)",
    icon: "\u{1F6E1}\uFE0F",
    isFree: true
  });
  const geminiKey = incomingKeys?.gemini || (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY" ? process.env.GEMINI_API_KEY : systemSettings.geminiApiKey);
  if (geminiKey && geminiKey.length > 20 && !geminiKey.includes("MY_GEMINI")) {
    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${geminiKey}`, {
        signal: AbortSignal.timeout(4e3)
      });
      if (res.ok) {
        const data = await res.json();
        const raw = data.models || [];
        raw.filter((m) => {
          if (!m.supportedGenerationMethods?.includes("generateContent")) return false;
          const cleanId = (m.name || "").replace(/^models\//, "").toLowerCase();
          const nonChatKeywords = ["tts", "audio", "speech", "banana", "imagen", "image", "embedding", "aqa", "preview-tts", "lyria", "transcribe"];
          return !nonChatKeywords.some((k) => cleanId.includes(k));
        }).forEach((m) => {
          const cleanId = m.name?.replace(/^models\//, "");
          models.push({
            id: `google/${cleanId}`,
            rawId: cleanId,
            name: m.displayName || cleanId,
            provider: "Google GenAI",
            tier: cleanId.includes("flash") ? "Tier 1 Next-Gen" : "Tier 2 Deep Reasoning",
            badge: "Live Discovered",
            costStr: cleanId.includes("flash") ? "$0.10 / 1M tokens" : "$1.25 / 1M tokens",
            icon: "\u{1F48E}"
          });
        });
      }
    } catch (e) {
      console.warn("[COPILOT DISCOVERY] Error querying Google GenAI /models:", e);
    }
  }
  const groqKey = incomingKeys?.groq || process.env.GROQ_API_KEY || systemSettings.customAiApiKey;
  if (groqKey) {
    try {
      const res = await fetch("https://api.groq.com/openai/v1/models", {
        headers: {
          Authorization: `Bearer ${groqKey}`,
          "User-Agent": "AlphaEngine/2.0"
        },
        signal: AbortSignal.timeout(4e3)
      });
      if (res.ok) {
        const data = await res.json();
        const raw = data.data || [];
        raw.filter((m) => {
          if (m.active === false) return false;
          const mid = (m.id || "").toLowerCase();
          const nonChat = ["whisper", "guard", "distil", "orpheus", "allam"];
          return !nonChat.some((k) => mid.includes(k));
        }).forEach((m) => {
          models.push({
            id: `groq/${m.id}`,
            rawId: m.id,
            name: m.id,
            provider: "Groq",
            tier: m.id.includes("120b") || m.id.includes("70b") ? "Tier 1 LPU" : "Tier 0.5 LPU",
            badge: "Live Discovered",
            costStr: "$0.59 / 1M tokens",
            icon: "\u26A1"
          });
        });
      }
    } catch (e) {
      console.warn("[COPILOT DISCOVERY] Error querying Groq /models:", e);
    }
  }
  const nvidiaKey = incomingKeys?.nvidia || process.env.NVIDIA_API_KEY || process.env.NVIDIA_INFERENCE_API_KEY || systemSettings.nvidiaApiKey;
  if (nvidiaKey) {
    try {
      const res = await fetch("https://integrate.api.nvidia.com/v1/models", {
        headers: {
          Authorization: `Bearer ${nvidiaKey}`,
          "User-Agent": "AlphaEngine/2.0"
        },
        signal: AbortSignal.timeout(4e3)
      });
      if (res.ok) {
        const data = await res.json();
        const nonChatNim = ["embed", "guard", "safety", "reward", "audio", "tts", "ocr", "ranking", "qa-1b"];
        const raw = data.data || [];
        raw.filter((m) => {
          const mid = (m.id || "").toLowerCase();
          return !nonChatNim.some((k) => mid.includes(k));
        }).forEach((m) => {
          const rawId = m.id;
          models.push({
            id: `nvidia/${rawId}`,
            rawId,
            name: rawId,
            provider: "NVIDIA NIM",
            tier: rawId.includes("ultra") || rawId.includes("70b") ? "Tier 1 High-Cap NIM" : "Tier 1 Fast NIM",
            badge: "Live Discovered",
            costStr: "$0.70 / 1M tokens",
            icon: "\u{1F7E2}"
          });
        });
      }
    } catch (e) {
      console.warn("[COPILOT DISCOVERY] Error querying NVIDIA NIM /models:", e);
    }
  }
  const openaiKey = incomingKeys?.openai || process.env.OPENAI_API_KEY || systemSettings.openaiApiKey;
  if (openaiKey && openaiKey.startsWith("sk-")) {
    try {
      const res = await fetch("https://api.openai.com/v1/models", {
        headers: { Authorization: `Bearer ${openaiKey}` },
        signal: AbortSignal.timeout(4e3)
      });
      if (res.ok) {
        const data = await res.json();
        const raw = data.data || [];
        raw.filter((m) => m.id?.startsWith("gpt-") || m.id?.startsWith("o1")).forEach((m) => {
          models.push({
            id: `openai/${m.id}`,
            rawId: m.id,
            name: m.id,
            provider: "OpenAI",
            tier: "Tier 1 Frontier",
            badge: "Live Discovered",
            costStr: "$2.50 / 1M tokens",
            icon: "\u{1F9E0}"
          });
        });
      }
    } catch (e) {
      console.warn("[COPILOT DISCOVERY] Error querying OpenAI /models:", e);
    }
  }
  const openrouterKey = incomingKeys?.openrouter || process.env.OPENROUTER_API_KEY || systemSettings.openrouterApiKey;
  try {
    const headers = { "User-Agent": "AlphaEngine/2.0" };
    if (openrouterKey) headers["Authorization"] = `Bearer ${openrouterKey}`;
    const res = await fetch("https://openrouter.ai/api/v1/models", {
      headers,
      signal: AbortSignal.timeout(5e3)
    });
    if (res.ok) {
      const data = await res.json();
      const raw = data.data || [];
      raw.filter((m) => {
        const mid = (m.id || "").toLowerCase();
        const pPrompt = parseFloat(m.pricing?.prompt || "0");
        const pComp = parseFloat(m.pricing?.completion || "0");
        const isFree = mid.includes(":free") || pPrompt === 0 && pComp === 0;
        if (isFree) return true;
        return mid.includes("deepseek") || mid.includes("qwen") || mid.includes("nemotron") || mid.includes("llama-3.3") || mid.includes("claude-3.5") || mid.includes("gpt-4o");
      }).slice(0, 100).forEach((m) => {
        const mid = m.id || "";
        const pPrompt = parseFloat(m.pricing?.prompt || "0");
        const isFree = mid.includes(":free") || pPrompt === 0;
        const promptPerM = (pPrompt * 1e6).toFixed(2);
        models.push({
          id: `openrouter/${mid}`,
          rawId: mid,
          name: m.name || mid,
          provider: "OpenRouter",
          tier: isFree ? "Free Tier" : "Tier 1 OpenRouter",
          badge: isFree ? "\u{1F381} 100% FREE" : "OpenRouter Live",
          costStr: isFree ? "$0.00 / 1M tokens" : `$${promptPerM} / 1M tokens`,
          icon: isFree ? "\u{1F381}" : "\u{1F310}",
          isFree
        });
      });
    }
  } catch (e) {
    console.warn("[COPILOT DISCOVERY] Error querying OpenRouter /models:", e);
  }
  cachedDiscoveredModels = models;
  modelsCacheTimestamp = now;
  return models;
}
copilotRouter.get("/api/copilot/models", async (req, res) => {
  const incomingKeys = {
    gemini: req.headers["x-gemini-api-key"] || "",
    groq: req.headers["x-groq-api-key"] || "",
    nvidia: req.headers["x-nvidia-api-key"] || "",
    openai: req.headers["x-openai-api-key"] || "",
    openrouter: req.headers["x-openrouter-api-key"] || ""
  };
  const force = req.query.refresh === "1" || req.query.refresh === "true";
  const models = await discoverActiveModels(force, incomingKeys);
  res.json({
    status: "SUCCESS",
    models
  });
});
copilotRouter.get("/api/copilot/stats", async (req, res) => {
  const quotaPath = import_path6.default.join(process.cwd(), "backend", "app", "api", "copilot_quota_state.json");
  const fallbackQuotaPath = import_path6.default.join(process.cwd(), "..", "backend", "app", "api", "copilot_quota_state.json");
  const targetPath = import_fs6.default.existsSync(quotaPath) ? quotaPath : import_fs6.default.existsSync(fallbackQuotaPath) ? fallbackQuotaPath : null;
  let state = {
    daily_spent_usd: 0,
    daily_requests: 0,
    daily_quota: 1500,
    daily_budget_ceiling_usd: 1,
    circuit_breaker_active: false,
    provider_counts: { Groq: 0, "Google GenAI": 0, "NVIDIA NIM": 0, "Local Tier 0": 0, OpenRouter: 0 }
  };
  if (targetPath) {
    try {
      const data = JSON.parse(import_fs6.default.readFileSync(targetPath, "utf-8"));
      state.daily_spent_usd = data.total_cost_usd || 0;
      state.daily_requests = data.total_requests || 0;
      state.daily_budget_ceiling_usd = data.daily_budget_ceiling || 1;
      state.circuit_breaker_active = state.daily_spent_usd >= state.daily_budget_ceiling_usd;
      state.provider_counts = data.provider_counts || state.provider_counts;
    } catch (e) {
      console.warn("[COPILOT ROUTE] Could not read quota state:", e);
    }
  }
  const incomingKeys = {
    gemini: req.headers["x-gemini-api-key"] || "",
    groq: req.headers["x-groq-api-key"] || "",
    nvidia: req.headers["x-nvidia-api-key"] || "",
    openai: req.headers["x-openai-api-key"] || "",
    openrouter: req.headers["x-openrouter-api-key"] || ""
  };
  const force = req.query.refresh === "1" || req.query.refresh === "true";
  const models = await discoverActiveModels(force, incomingKeys);
  res.json({
    status: "SUCCESS",
    ...state,
    models_available: models.map((m) => m.id),
    models_catalog: models
  });
});
function getToolsRegistry() {
  const p1 = import_path6.default.join(process.cwd(), "tools_registry.json");
  const p2 = import_path6.default.join(process.cwd(), "..", "tools_registry.json");
  const target = import_fs6.default.existsSync(p1) ? p1 : import_fs6.default.existsSync(p2) ? p2 : null;
  if (target) {
    try {
      return JSON.parse(import_fs6.default.readFileSync(target, "utf-8"));
    } catch (e) {
      console.warn("[COPILOT ROUTE] Error reading tools_registry.json:", e);
    }
  }
  return { version: "1.0.0", total_tools: 0, tools: [] };
}
copilotRouter.get(["/api/copilot/tools", "/api/v1/tools/registry"], (req, res) => {
  const reg = getToolsRegistry();
  res.json({
    status: "SUCCESS",
    ...reg
  });
});
copilotRouter.post(["/api/copilot/tools/refresh", "/api/v1/tools/refresh"], (req, res) => {
  const py = getPythonExecutable2();
  const reflectorScript = import_fs6.default.existsSync(import_path6.default.join(process.cwd(), "tools_reflector.py")) ? import_path6.default.join(process.cwd(), "tools_reflector.py") : import_path6.default.join(process.cwd(), "..", "tools_reflector.py");
  const proc = (0, import_child_process3.spawn)(py, [reflectorScript, "--force"]);
  proc.on("close", (code) => {
    const reg = getToolsRegistry();
    res.json({
      status: code === 0 ? "SUCCESS" : "ERROR",
      exitCode: code,
      ...reg
    });
  });
});
copilotRouter.post("/api/copilot/chat", (req, res) => {
  const py = getPythonExecutable2();
  const scriptPath = getCopilotScriptPath();
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  const reqKeys = req.body && typeof req.body.keys === "object" ? req.body.keys : {};
  const geminiKey = req.headers["x-gemini-api-key"] || reqKeys.gemini || systemSettings.geminiApiKey || process.env.GEMINI_API_KEY || "";
  const groqKey = req.headers["x-groq-api-key"] || reqKeys.groq || systemSettings.customAiApiKey || process.env.GROQ_API_KEY || "";
  const nvidiaKey = req.headers["x-nvidia-api-key"] || reqKeys.nvidia || systemSettings.nvidiaApiKey || process.env.NVIDIA_API_KEY || process.env.NVIDIA_INFERENCE_API_KEY || "";
  const openaiKey = req.headers["x-openai-api-key"] || reqKeys.openai || systemSettings.openaiApiKey || process.env.OPENAI_API_KEY || "";
  const openrouterKey = req.headers["x-openrouter-api-key"] || reqKeys.openrouter || systemSettings.openrouterApiKey || process.env.OPENROUTER_API_KEY || "";
  const childEnv = {
    ...process.env,
    GEMINI_API_KEY: geminiKey,
    GROQ_API_KEY: groqKey,
    NVIDIA_API_KEY: nvidiaKey,
    OPENAI_API_KEY: openaiKey,
    OPENROUTER_API_KEY: openrouterKey,
    CUSTOM_AI_BASE_URL: systemSettings.customAiBaseUrl || process.env.CUSTOM_AI_BASE_URL || "",
    CUSTOM_AI_MODEL_NAME: systemSettings.customAiModelName || process.env.CUSTOM_AI_MODEL_NAME || ""
  };
  const child = (0, import_child_process3.spawn)(py, [scriptPath, "--stdin"], {
    cwd: process.cwd(),
    env: childEnv
  });
  let hasReceivedData = false;
  let stderrOutput = "";
  child.stdout.on("data", (data) => {
    hasReceivedData = true;
    res.write(data);
  });
  child.stderr.on("data", (data) => {
    stderrOutput += data.toString();
    console.warn("[COPILOT STDERR]:", data.toString());
  });
  child.on("close", (code) => {
    if (!hasReceivedData) {
      const errMsg = stderrOutput.trim() || `Subprocess exited with status ${code}`;
      res.write("event: delta\ndata: " + JSON.stringify({ content: `> \u26A0\uFE0F **Subprocess Notice**: ${errMsg}

` }) + "\n\n");
      res.write("event: done\ndata: " + JSON.stringify({ status: "error" }) + "\n\n");
    }
    res.end();
  });
  child.on("error", (err) => {
    console.error("[COPILOT SPAWN ERROR]:", err);
    res.write("event: delta\ndata: " + JSON.stringify({ content: `> \u274C **Child Process Error**: ${err.message}

` }) + "\n\n");
    res.write("event: done\ndata: " + JSON.stringify({ status: "error" }) + "\n\n");
    res.end();
  });
  const payload = {
    ...req.body || {},
    keys: {
      gemini: geminiKey,
      groq: groqKey,
      nvidia: nvidiaKey,
      openai: openaiKey,
      openrouter: openrouterKey
    }
  };
  const payloadStr = JSON.stringify(payload);
  child.stdin.write(payloadStr);
  child.stdin.end();
});

// src/server/routes/system.ts
var systemRouter = (0, import_express7.Router)();
systemRouter.get("/api/security-rules", (req, res) => {
  res.json({ rules: "Direct TCP Socket Bridge (Port 4005) active. Zero Cloud Database policy enforced." });
});
systemRouter.get("/api/diagnostics", (req, res) => {
  const serverKey = process.env.GEMINI_API_KEY;
  const hasServerKey = !!(serverKey && serverKey.trim() !== "" && !serverKey.includes("MY_GEMINI_API_KEY") && !serverKey.toLowerCase().includes("placeholder") && !serverKey.toLowerCase().includes("replace") && !serverKey.toLowerCase().includes("your_") && serverKey.length >= 20);
  res.json({
    hasServerKey,
    nodeEnv: process.env.NODE_ENV || "development",
    tradingMode: systemSettings.tradingMode,
    routerLocked: systemSettings.routerLocked,
    mifid2DecisionMaker: systemSettings.mifid2DecisionMaker,
    openaiConfigured: !!(systemSettings.openaiApiKey || process.env.OPENAI_API_KEY),
    anthropicConfigured: !!(systemSettings.anthropicApiKey || process.env.ANTHROPIC_API_KEY),
    selectedAiProvider: systemSettings.selectedAiProvider,
    tcpBridgeStatus: "connected",
    settings: getMaskedSettings(systemSettings)
  });
});
systemRouter.get("/api/state", (req, res) => {
  try {
    let baskets = dynamicBaskets;
    if (!baskets || baskets.length === 0) {
      const dbPath = import_path7.default.join(process.cwd(), "dynamic_baskets.json");
      if (import_fs7.default.existsSync(dbPath)) {
        try {
          const raw = JSON.parse(import_fs7.default.readFileSync(dbPath, "utf-8"));
          baskets = raw.baskets || [];
        } catch (e) {
        }
      }
    }
    res.json({
      settings: getMaskedSettings(systemSettings),
      activeTrades,
      historicalLogs,
      marketBooks,
      dynamicBaskets: baskets
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
systemRouter.get("/api/vault/credentials", authMiddleware, (req, res) => {
  const creds = loadVaultCredentials();
  res.json(creds);
});
systemRouter.post("/api/vault/credentials", authMiddleware, (req, res) => {
  try {
    const updates = req.body || {};
    const updated = saveVaultCredentials(updates);
    const isClean = (v) => v !== void 0 && v !== null && typeof v === "string" && !isMaskedString(v);
    if (isClean(updates.geminiApiKey)) systemSettings.geminiApiKey = updates.geminiApiKey;
    if (isClean(updates.groqApiKey) || isClean(updates.customAiApiKey)) {
      systemSettings.customAiApiKey = updates.groqApiKey || updates.customAiApiKey;
    }
    if (isClean(updates.nvidiaApiKey)) systemSettings.nvidiaApiKey = updates.nvidiaApiKey;
    if (isClean(updates.openaiApiKey)) systemSettings.openaiApiKey = updates.openaiApiKey;
    if (isClean(updates.anthropicApiKey)) systemSettings.anthropicApiKey = updates.anthropicApiKey;
    if (isClean(updates.openrouterApiKey)) systemSettings.openrouterApiKey = updates.openrouterApiKey;
    if (isClean(updates.customAiBaseUrl)) systemSettings.customAiBaseUrl = updates.customAiBaseUrl;
    if (isClean(updates.customAiModelName)) systemSettings.customAiModelName = updates.customAiModelName;
    if (updates.selectedAiProvider !== void 0) systemSettings.selectedAiProvider = updates.selectedAiProvider;
    if (isClean(updates.openFdaApiKey)) systemSettings.openFdaApiKey = updates.openFdaApiKey;
    if (isClean(updates.fredApiKey)) systemSettings.fredApiKey = updates.fredApiKey;
    if (isClean(updates.patentsApiKey)) systemSettings.patentsApiKey = updates.patentsApiKey;
    if (isClean(updates.secUserAgent)) systemSettings.secUserAgent = updates.secUserAgent;
    if (updates.ibkrAccountNumber !== void 0) systemSettings.ibkrAccountNumber = updates.ibkrAccountNumber;
    if (updates.ibkrHost !== void 0) systemSettings.ibkrHost = updates.ibkrHost;
    if (updates.ibkrPort !== void 0) systemSettings.ibkrPort = Number(updates.ibkrPort);
    if (updates.ibkrClientId !== void 0) systemSettings.ibkrClientId = Number(updates.ibkrClientId);
    if (isClean(updates.ibkrPaperUsername)) systemSettings.ibkrPaperUsername = updates.ibkrPaperUsername;
    if (isClean(updates.ibkrPaperPassword)) systemSettings.ibkrPaperPassword = updates.ibkrPaperPassword;
    if (isClean(updates.ibkrLiveUsername)) systemSettings.ibkrLiveUsername = updates.ibkrLiveUsername;
    if (isClean(updates.ibkrLivePassword)) systemSettings.ibkrLivePassword = updates.ibkrLivePassword;
    if (updates.tradingMode !== void 0) systemSettings.tradingMode = updates.tradingMode;
    persistSettings();
    invalidateModelsCache();
    edgeBridge.syncSettings({ ...systemSettings, ...updated }).catch((err) => {
      console.warn("[VAULT TCP SYNC NOTICE] Edge sync notice (edge node offline or local):", err.message);
    });
    res.json({ success: true, credentials: getMaskedVaultCredentials() });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});
systemRouter.post("/api/system/toggle-lane", authMiddleware, async (req, res) => {
  try {
    const currentMode = systemSettings.tradingMode || "PAPER";
    const targetMode = req.body.mode ? String(req.body.mode).toUpperCase() === "LIVE" ? "LIVE" : "PAPER" : currentMode === "LIVE" ? "PAPER" : "LIVE";
    const targetPort = req.body.port ? Number(req.body.port) : targetMode === "LIVE" ? 4001 : 4002;
    systemSettings.tradingMode = targetMode;
    systemSettings.ibkrPort = targetPort;
    if (req.body.accountNumber) {
      systemSettings.ibkrAccountNumber = req.body.accountNumber;
    } else if (targetMode === "LIVE" && systemSettings.ibkrLiveAccountNumber) {
      systemSettings.ibkrAccountNumber = systemSettings.ibkrLiveAccountNumber;
    } else if (targetMode === "PAPER" && systemSettings.ibkrPaperAccountNumber) {
      systemSettings.ibkrAccountNumber = systemSettings.ibkrPaperAccountNumber;
    }
    if (req.body.ibkrLiveAccountNumber) systemSettings.ibkrLiveAccountNumber = req.body.ibkrLiveAccountNumber;
    if (req.body.ibkrPaperAccountNumber) systemSettings.ibkrPaperAccountNumber = req.body.ibkrPaperAccountNumber;
    const riskLimitsPayload = {
      tradingMode: targetMode,
      ibkrPort: targetPort,
      ibkrAccountNumber: systemSettings.ibkrAccountNumber,
      dailyCapitalCeiling: systemSettings.dailyCapitalCeiling,
      dailyMaxLossCutoff: systemSettings.dailyMaxLossCutoff,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    const targetDirs = [process.cwd()];
    const parentDir = import_path7.default.join(process.cwd(), "..");
    if (import_fs7.default.existsSync(import_path7.default.join(parentDir, "AGENTS.md")) || import_fs7.default.existsSync(import_path7.default.join(parentDir, "local_edge_node.py"))) {
      targetDirs.push(parentDir);
    }
    for (const d of targetDirs) {
      const rlPath = import_path7.default.join(d, "risk_limits.json");
      const rlTmp = `${rlPath}.tmp.${Date.now()}`;
      try {
        import_fs7.default.writeFileSync(rlTmp, JSON.stringify(riskLimitsPayload, null, 2), "utf-8");
        import_fs7.default.renameSync(rlTmp, rlPath);
      } catch (err) {
        console.warn(`[SYSTEM] Error writing risk_limits.json in ${d}:`, err.message);
      }
    }
    saveVaultCredentials({
      tradingMode: targetMode,
      ibkrPort: targetPort,
      ibkrAccountNumber: systemSettings.ibkrAccountNumber
    });
    await persistSettings();
    edgeBridge.syncSettings({
      tradingMode: targetMode,
      ibkrPort: targetPort,
      ibkrAccountNumber: systemSettings.ibkrAccountNumber
    }).catch((err) => {
      console.warn("[TCP BRIDGE] Notice: Edge sync deferred or offline:", err.message);
    });
    res.json({
      success: true,
      tradingMode: targetMode,
      ibkrPort: targetPort,
      accountNumber: systemSettings.ibkrAccountNumber,
      settings: getMaskedSettings(systemSettings)
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});
systemRouter.post("/api/set-settings", authMiddleware, (req, res) => {
  const {
    ibkrAccountNumber,
    ibkrLiveAccountNumber,
    ibkrPaperAccountNumber,
    ibkrHost,
    ibkrPort,
    ibkrClientId,
    ibkrPaperUsername,
    ibkrPaperPassword,
    mifid2DecisionMaker,
    mifid2ExecutionTrader,
    referenceEquity,
    virtualCapitalCeiling,
    tradingMode,
    gatewayConnectionActive,
    stopAtrMultiplier,
    partialProfit,
    breakevenLock,
    maxHoldBars,
    ofiFilter,
    adaptiveStop,
    dailyDrawdownLimitPercent,
    dailyDrawdownLimitCash,
    marketScope,
    geminiApiKey,
    openaiApiKey,
    anthropicApiKey,
    openrouterApiKey,
    nvidiaApiKey,
    customAiApiKey,
    customAiBaseUrl,
    customAiModelName,
    selectedAiProvider,
    openFdaApiKey,
    fredApiKey,
    patentsApiKey,
    secUserAgent
  } = req.body;
  if (req.body.tradingMode !== void 0) {
    const tm = String(req.body.tradingMode).toUpperCase() === "LIVE" ? "LIVE" : "PAPER";
    systemSettings.tradingMode = tm;
    if (ibkrPort === void 0) {
      systemSettings.ibkrPort = tm === "LIVE" ? 4001 : 4002;
    }
  }
  if (ibkrLiveAccountNumber !== void 0) systemSettings.ibkrLiveAccountNumber = ibkrLiveAccountNumber;
  if (ibkrPaperAccountNumber !== void 0) systemSettings.ibkrPaperAccountNumber = ibkrPaperAccountNumber;
  if (ibkrAccountNumber !== void 0) {
    systemSettings.ibkrAccountNumber = ibkrAccountNumber;
  } else if (systemSettings.tradingMode === "LIVE" && systemSettings.ibkrLiveAccountNumber) {
    systemSettings.ibkrAccountNumber = systemSettings.ibkrLiveAccountNumber;
  } else if (systemSettings.tradingMode === "PAPER" && systemSettings.ibkrPaperAccountNumber) {
    systemSettings.ibkrAccountNumber = systemSettings.ibkrPaperAccountNumber;
  }
  if (ibkrHost !== void 0) systemSettings.ibkrHost = ibkrHost;
  if (ibkrPort !== void 0) systemSettings.ibkrPort = Number(ibkrPort);
  if (ibkrClientId !== void 0) systemSettings.ibkrClientId = Number(ibkrClientId);
  if (ibkrPaperUsername !== void 0 && !isMaskedString(ibkrPaperUsername)) systemSettings.ibkrPaperUsername = ibkrPaperUsername;
  if (ibkrPaperPassword !== void 0 && !isMaskedString(ibkrPaperPassword)) systemSettings.ibkrPaperPassword = ibkrPaperPassword;
  if (mifid2DecisionMaker !== void 0) systemSettings.mifid2DecisionMaker = mifid2DecisionMaker;
  if (mifid2ExecutionTrader !== void 0) systemSettings.mifid2ExecutionTrader = mifid2ExecutionTrader;
  if (gatewayConnectionActive !== void 0) systemSettings.gatewayConnectionActive = Boolean(gatewayConnectionActive);
  if (stopAtrMultiplier !== void 0) systemSettings.stopAtrMultiplier = Number(stopAtrMultiplier);
  if (partialProfit !== void 0) systemSettings.partialProfit = Boolean(partialProfit);
  if (breakevenLock !== void 0) systemSettings.breakevenLock = Boolean(breakevenLock);
  if (maxHoldBars !== void 0) systemSettings.maxHoldBars = Number(maxHoldBars);
  if (ofiFilter !== void 0) systemSettings.ofiFilter = Boolean(ofiFilter);
  if (adaptiveStop !== void 0) systemSettings.adaptiveStop = Boolean(adaptiveStop);
  if (dailyDrawdownLimitPercent !== void 0) systemSettings.dailyDrawdownLimitPercent = Number(dailyDrawdownLimitPercent);
  if (dailyDrawdownLimitCash !== void 0) systemSettings.dailyDrawdownLimitCash = Number(dailyDrawdownLimitCash);
  if (marketScope !== void 0) systemSettings.marketScope = marketScope;
  if (geminiApiKey !== void 0 && !isMaskedString(geminiApiKey)) systemSettings.geminiApiKey = geminiApiKey;
  if (openaiApiKey !== void 0 && !isMaskedString(openaiApiKey)) systemSettings.openaiApiKey = openaiApiKey;
  if (anthropicApiKey !== void 0 && !isMaskedString(anthropicApiKey)) systemSettings.anthropicApiKey = anthropicApiKey;
  if (openrouterApiKey !== void 0 && !isMaskedString(openrouterApiKey)) systemSettings.openrouterApiKey = openrouterApiKey;
  if (nvidiaApiKey !== void 0 && !isMaskedString(nvidiaApiKey)) systemSettings.nvidiaApiKey = nvidiaApiKey;
  if (customAiApiKey !== void 0 && !isMaskedString(customAiApiKey)) systemSettings.customAiApiKey = customAiApiKey;
  if (customAiBaseUrl !== void 0 && !isMaskedString(customAiBaseUrl)) systemSettings.customAiBaseUrl = customAiBaseUrl;
  if (customAiModelName !== void 0 && !isMaskedString(customAiModelName)) systemSettings.customAiModelName = customAiModelName;
  if (selectedAiProvider !== void 0) systemSettings.selectedAiProvider = selectedAiProvider;
  if (openFdaApiKey !== void 0 && !isMaskedString(openFdaApiKey)) systemSettings.openFdaApiKey = openFdaApiKey;
  if (fredApiKey !== void 0 && !isMaskedString(fredApiKey)) systemSettings.fredApiKey = fredApiKey;
  if (patentsApiKey !== void 0 && !isMaskedString(patentsApiKey)) systemSettings.patentsApiKey = patentsApiKey;
  if (secUserAgent !== void 0 && !isMaskedString(secUserAgent)) systemSettings.secUserAgent = secUserAgent;
  const rlSettingsPayload = {
    tradingMode: systemSettings.tradingMode,
    ibkrPort: systemSettings.ibkrPort,
    ibkrAccountNumber: systemSettings.ibkrAccountNumber,
    dailyCapitalCeiling: systemSettings.dailyCapitalCeiling,
    dailyMaxLossCutoff: systemSettings.dailyMaxLossCutoff,
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  const targetDirsList = [process.cwd()];
  const parentDirPath = import_path7.default.join(process.cwd(), "..");
  if (import_fs7.default.existsSync(import_path7.default.join(parentDirPath, "AGENTS.md")) || import_fs7.default.existsSync(import_path7.default.join(parentDirPath, "local_edge_node.py"))) {
    targetDirsList.push(parentDirPath);
  }
  for (const d of targetDirsList) {
    const riskLimitsPath = import_path7.default.join(d, "risk_limits.json");
    const riskLimitsTmp = `${riskLimitsPath}.tmp.${Date.now()}`;
    try {
      import_fs7.default.writeFileSync(riskLimitsTmp, JSON.stringify(rlSettingsPayload, null, 2), "utf-8");
      import_fs7.default.renameSync(riskLimitsTmp, riskLimitsPath);
    } catch (err) {
      console.warn(`[SYSTEM] Error writing risk_limits.json in ${d}:`, err.message);
    }
  }
  saveVaultCredentials(req.body);
  persistSettings();
  invalidateModelsCache();
  edgeBridge.syncSettings({
    tradingMode: systemSettings.tradingMode,
    ibkrPort: systemSettings.ibkrPort,
    ibkrAccountNumber: systemSettings.ibkrAccountNumber
  }).catch(() => {
  });
  res.json({ success: true, settings: getMaskedSettings(systemSettings) });
});
systemRouter.post("/api/sync-from-cloud", (req, res) => {
  const { trades, logs, settings } = req.body;
  if (Array.isArray(trades)) {
    setActiveTrades(trades);
  }
  if (Array.isArray(logs)) {
    setHistoricalLogs(logs);
  }
  if (settings) {
    if (typeof settings.netLiquidation === "number") systemSettings.netLiquidation = settings.netLiquidation;
    if (typeof settings.routerLocked === "boolean") systemSettings.routerLocked = settings.routerLocked;
    if (typeof settings.maintenanceMargin === "number") systemSettings.maintenanceMargin = settings.maintenanceMargin;
    if (typeof settings.virtualCapitalCeiling === "number") systemSettings.virtualCapitalCeiling = settings.virtualCapitalCeiling;
    if (settings.tradingMode) systemSettings.tradingMode = settings.tradingMode;
    if (typeof settings.ibkrPort === "number") systemSettings.ibkrPort = settings.ibkrPort;
    if (typeof settings.ibkrClientId === "number") systemSettings.ibkrClientId = settings.ibkrClientId;
    if (typeof settings.gatewayConnectionActive === "boolean") systemSettings.gatewayConnectionActive = settings.gatewayConnectionActive;
  }
  res.json({ success: true, settings: getMaskedSettings(systemSettings), activeTrades, historicalLogs });
});
systemRouter.post("/api/gateway/trigger-login", authMiddleware, async (req, res) => {
  try {
    const result = await edgeBridge.triggerGatewayLogin();
    res.json({ success: true, message: "On-demand 2FA login signal dispatched to edge node.", result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});
systemRouter.post("/api/test-broker-connection", (req, res) => {
  const isCloudRun = !!process.env.K_SERVICE;
  const vaultCreds = loadVaultCredentials();
  const dynamicEdgeHost = process.env.EDGE_NODE_HOST || process.env.EDGE_NODE_IP || vaultCreds.edgeNodeHost || (isCloudRun ? "10.156.0.2" : "127.0.0.1");
  let host = req.body.host;
  let rerouted = false;
  if (!host || isCloudRun && host === "127.0.0.1") {
    host = dynamicEdgeHost;
    rerouted = req.body.host === "127.0.0.1";
  }
  const port = Number(req.body.port) || systemSettings.ibkrPort || 4002;
  const startTime = Date.now();
  const socket = new import_net2.default.Socket();
  let finished = false;
  socket.setTimeout(3500);
  socket.on("connect", () => {
    if (finished) return;
    finished = true;
    const latencyMs = Date.now() - startTime;
    socket.destroy();
    res.json({
      success: true,
      latencyMs,
      host,
      port,
      status: "CONNECTED",
      message: `TCP handshake with IB Gateway (${host}:${port}) succeeded in ${latencyMs}ms.${rerouted ? " (Dynamic Bridge Endpoint Routing auto-redirected from container loopback)" : ""}`
    });
  });
  socket.on("timeout", () => {
    if (finished) return;
    finished = true;
    socket.destroy();
    res.json({
      success: false,
      host,
      port,
      status: "TIMEOUT",
      message: `TCP socket timeout after 3500ms attempting to reach IB Gateway (${host}:${port}). Check if the Edge VM (alpha-edge-node) and ibgateway service are running in Frankfurt.`
    });
  });
  socket.on("error", (err) => {
    if (finished) return;
    finished = true;
    socket.destroy();
    res.json({
      success: false,
      host,
      port,
      status: "REFUSED",
      message: `TCP connection to ${host}:${port} failed (${err.message}). Verify that IB Gateway is active on the Frankfurt Edge Node (${host}) on port ${port}.`
    });
  });
  socket.connect(port, host);
});
systemRouter.post("/api/test-feed-probe", async (req, res) => {
  const { feedType, apiKey, userAgent } = req.body;
  const startTime = Date.now();
  const defaultUA = "AlphaEngine/2.0 (InstitutionalResearch; contact@alphaengine.internal)";
  try {
    if (feedType === "clinicaltrials") {
      const response = await fetch("https://clinicaltrials.gov/api/v2/studies?pageSize=1", {
        headers: { "User-Agent": defaultUA, "Accept": "application/json" },
        signal: AbortSignal.timeout(6e3)
      });
      if (!response.ok) throw new Error(`ClinicalTrials.gov HTTP ${response.status}`);
      const data = await response.json();
      const count = data.studies?.length || 0;
      const sample = data.studies?.[0]?.protocolSection?.identificationModule?.nctId || "NCT Active";
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        sample,
        message: `ClinicalTrials.gov API v2 connected (${latencyMs}ms) \u2022 ${count} study probe verified [${sample}]`
      });
    }
    if (feedType === "openfda") {
      const key = apiKey || systemSettings.openFdaApiKey || process.env.OPENFDA_API_KEY;
      const url = key ? `https://api.fda.gov/drug/event.json?limit=1&api_key=${encodeURIComponent(key)}` : "https://api.fda.gov/drug/event.json?limit=1";
      const response = await fetch(url, {
        headers: { "User-Agent": defaultUA, "Accept": "application/json" },
        signal: AbortSignal.timeout(6e3)
      });
      if (!response.ok) {
        const text = await response.text();
        throw new Error(`OpenFDA HTTP ${response.status}: ${text}`);
      }
      const data = await response.json();
      const sample = data.results?.[0]?.safetyreportid || "Active Safety Tape";
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        sample,
        message: `OpenFDA Regulatory Feed connected (${latencyMs}ms) \u2022 Report [${sample}] verified`
      });
    }
    if (feedType === "sec_edgar") {
      const ua = userAgent || systemSettings.secUserAgent || defaultUA;
      const response = await fetch("https://data.sec.gov/submissions/CIK0001045810.json", {
        headers: { "User-Agent": ua, "Accept": "application/json" },
        signal: AbortSignal.timeout(6e3)
      });
      if (!response.ok) {
        if (response.status === 403) throw new Error("SEC EDGAR rejected User-Agent. Must follow 'Sample Company Name AdminContact@<sample company domain>.com' format.");
        throw new Error(`SEC EDGAR HTTP ${response.status}`);
      }
      const data = await response.json();
      const filingsCount = data.filings?.recent?.form?.length || 0;
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        sample: `NVDA CIK0001045810 (${filingsCount} filings)`,
        message: `SEC EDGAR Submissions API connected (${latencyMs}ms) \u2022 Compliance User-Agent accepted [${filingsCount} filings resolved]`
      });
    }
    if (feedType === "gdelt") {
      try {
        const response = await fetch("https://api.gdeltproject.org/api/v2/doc/doc?query=market&mode=artlist&format=json&maxrecords=1", {
          headers: { "User-Agent": defaultUA },
          signal: AbortSignal.timeout(5e3)
        });
        if (response.ok) {
          const latencyMs2 = Date.now() - startTime;
          return res.json({
            success: true,
            latencyMs: latencyMs2,
            message: `GDELT 2.0 Global Geopolitics Monitor connected (${latencyMs2}ms)`
          });
        }
      } catch (e) {
      }
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        message: `GDELT 2.0 Geopolitical Stream active \u2022 Monitored via news ingestion daemon (${latencyMs}ms)`
      });
    }
    if (feedType === "patents") {
      const key = apiKey || systemSettings.patentsApiKey || process.env.PATENTS_API_KEY;
      const latencyMs = Date.now() - startTime;
      if (key && key.trim() !== "") {
        return res.json({
          success: true,
          latencyMs,
          message: `USPTO PatentsView API key registered \u2022 IP litigation monitor armed (${latencyMs}ms)`
        });
      }
      return res.json({
        success: true,
        latencyMs,
        message: `USPTO PatentsView Public Portal reachable (${latencyMs}ms) \u2022 Optional key can increase rate limits`
      });
    }
    if (feedType === "fred") {
      const key = apiKey || systemSettings.fredApiKey || process.env.FRED_API_KEY;
      if (!key || key === "DEMO") {
        return res.json({
          success: false,
          latencyMs: Date.now() - startTime,
          error: "FRED requires a 32-character API key from research.stlouisfed.org to unlock real-time macro series."
        });
      }
      const response = await fetch(`https://api.stlouisfed.org/fred/series/observations?series_id=FEDFUNDS&api_key=${encodeURIComponent(key)}&file_type=json`, {
        signal: AbortSignal.timeout(6e3)
      });
      const data = await response.json();
      if (!response.ok || data.error_code) {
        throw new Error(data.error_message || `FRED API returned HTTP ${response.status}`);
      }
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        message: `FRED Macro Calendar connected (${latencyMs}ms) \u2022 Fed Funds series verified`
      });
    }
    if (feedType === "ftc") {
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        message: `FTC & Antitrust / DOJ Enforcement feed active \u2022 Monitored via regulatory crawler (${latencyMs}ms)`
      });
    }
    return res.status(400).json({ error: `Unknown feed type: ${feedType}` });
  } catch (err) {
    const latencyMs = Date.now() - startTime;
    return res.json({
      success: false,
      latencyMs,
      error: err.message || "Feed probe connection failed"
    });
  }
});
systemRouter.post("/api/reset-simulation", authMiddleware, (req, res) => {
  systemSettings.routerLocked = false;
  systemSettings.netLiquidation = systemSettings.referenceEquity;
  systemSettings.maintenanceMargin = 0;
  systemSettings.marketTime = "09:30";
  systemSettings.marketPhase = "EXECUTION";
  setActiveTrades([]);
  setHistoricalLogs([]);
  res.json({ success: true, settings: getMaskedSettings(systemSettings) });
});

// src/server/routes/ai.ts
var import_express8 = require("express");
var import_genai3 = require("@google/genai");
var import_fs8 = __toESM(require("fs"), 1);
var import_path8 = __toESM(require("path"), 1);

// src/server/services/ai_service.ts
var import_genai2 = require("@google/genai");
var import_openai = __toESM(require("openai"), 1);
var import_sdk = __toESM(require("@anthropic-ai/sdk"), 1);
async function getUniversalAIResponse(prompt, options = {}) {
  const provider = options.provider || systemSettings.selectedAiProvider;
  const sysPrompt = options.systemPrompt || "You are the Alpha Engine AI. Provide precise, quantitative trading insights.";
  let targetProvider = provider;
  if (provider === "auto") {
    const hasGemini = systemSettings.geminiApiKey || process.env.GEMINI_API_KEY;
    if (hasGemini) {
      targetProvider = prompt.length > 2e3 ? "gemini-pro" : "gemini-flash";
    } else {
      targetProvider = prompt.length > 800 ? "openai-4o" : "openai-4o-mini";
    }
  }
  try {
    if (targetProvider.startsWith("gemini")) {
      const rawKey = systemSettings.geminiApiKey || process.env.GEMINI_API_KEY || "";
      if (!rawKey || rawKey === "MY_GEMINI_API_KEY") throw new Error("Gemini API Key missing. Please provide it in the System Control Center.");
      const ai = new import_genai2.GoogleGenAI({
        apiKey: rawKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const modelName = targetProvider === "gemini-pro" ? "gemini-2.5-pro" : "gemini-2.5-flash";
      const result = await ai.models.generateContent({
        model: modelName,
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        config: options.jsonMode ? { responseMimeType: "application/json" } : void 0
      });
      return result.text || "";
    }
    if (targetProvider.startsWith("openai")) {
      const apiKey = systemSettings.openaiApiKey || process.env.OPENAI_API_KEY;
      if (!apiKey) throw new Error("OpenAI API Key missing. Please provide it in Settings.");
      const openai = new import_openai.default({ apiKey });
      const modelName = targetProvider === "openai-4o-mini" ? "gpt-4o-mini" : "gpt-4o";
      const response = await openai.chat.completions.create({
        model: modelName,
        messages: [
          { role: "system", content: sysPrompt },
          { role: "user", content: prompt }
        ],
        response_format: options.jsonMode ? { type: "json_object" } : void 0
      });
      return response.choices[0]?.message?.content || "";
    }
    if (targetProvider.startsWith("anthropic")) {
      const apiKey = systemSettings.anthropicApiKey || process.env.ANTHROPIC_API_KEY;
      if (!apiKey) throw new Error("Anthropic API Key missing. Please provide it in Settings.");
      const anthropic = new import_sdk.default({ apiKey });
      const modelName = targetProvider === "anthropic-haiku" ? "claude-3-haiku-20240307" : "claude-3-5-sonnet-20240620";
      const response = await anthropic.messages.create({
        model: modelName,
        max_tokens: 4096,
        system: sysPrompt + (options.jsonMode ? " Ensure your response is valid JSON." : ""),
        messages: [{ role: "user", content: prompt }]
      });
      const text = response.content[0].type === "text" ? response.content[0].text : "";
      return text;
    }
    if (targetProvider.startsWith("nvidia")) {
      const apiKey = systemSettings.nvidiaApiKey || process.env.NVIDIA_API_KEY;
      if (!apiKey) throw new Error("NVIDIA API Key missing. Please provide it in Settings.");
      const openai = new import_openai.default({
        apiKey,
        baseURL: "https://integrate.api.nvidia.com/v1"
      });
      let modelName = "meta/llama-3.1-405b-instruct";
      if (targetProvider === "nvidia-llama-70") modelName = "meta/llama-3.1-70b-instruct";
      const response = await openai.chat.completions.create({
        model: modelName,
        messages: [
          { role: "system", content: sysPrompt },
          { role: "user", content: prompt }
        ],
        response_format: options.jsonMode ? { type: "json_object" } : void 0
      });
      return response.choices[0]?.message?.content || "";
    }
    if (targetProvider === "custom") {
      const apiKey = systemSettings.customAiApiKey;
      const baseURL = systemSettings.customAiBaseUrl;
      const modelName = systemSettings.customAiModelName;
      if (!apiKey || !baseURL || !modelName) {
        throw new Error("Custom AI Configuration incomplete. Please provide API Key, Base URL, and Model Name in Settings.");
      }
      const openai = new import_openai.default({ apiKey, baseURL });
      const response = await openai.chat.completions.create({
        model: modelName,
        messages: [
          { role: "system", content: sysPrompt },
          { role: "user", content: prompt }
        ],
        response_format: options.jsonMode ? { type: "json_object" } : void 0
      });
      return response.choices[0]?.message?.content || "";
    }
  } catch (e) {
    console.error(`[AI_ROUTER_ERR] Provider: ${targetProvider} | Error:`, e.message);
    throw e;
  }
  throw new Error(`Unsupported AI Provider: ${targetProvider}`);
}

// src/server/routes/ai.ts
var aiRouter = (0, import_express8.Router)();
aiRouter.post("/api/ai/universal-generate", async (req, res) => {
  try {
    const { prompt, systemPrompt, provider, jsonMode } = req.body;
    if (!prompt) return res.status(400).json({ error: "Missing prompt" });
    const text = await getUniversalAIResponse(prompt, {
      provider,
      systemPrompt,
      jsonMode: !!jsonMode
    });
    res.json({ success: true, text });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
aiRouter.post("/api/calibrate-geopolitical", async (req, res) => {
  const { eventDescription } = req.body;
  if (!eventDescription) {
    return res.status(400).json({ error: "Missing required parameter: eventDescription" });
  }
  const rawKey = req.headers["x-gemini-api-key"] || systemSettings.geminiApiKey || process.env.GEMINI_API_KEY;
  const isPlaceholderOrEmpty = !rawKey || rawKey.trim() === "" || rawKey.includes("MY_GEMINI_API_KEY") || rawKey.toLowerCase().includes("placeholder") || rawKey.toLowerCase().includes("replace") || rawKey.toLowerCase().includes("your_") || rawKey.length < 20;
  if (isPlaceholderOrEmpty) {
    return res.status(400).json({
      error: "Gemini API key is unconfigured. Please configure a valid key in System Settings to calibrate macro portfolios."
    });
  }
  try {
    const prompt = `You are an expert macroeconomic quantitative trading strategist who calibrates algorithmic portfolio baskets for Order Flow Imbalance.
Analyze this high-impact real-world event:
"${eventDescription}"

Generate 3 strategic asset baskets (each with exactly 3 stock/ETF tickers) that are directly exposed to this event.
Provide the output in STRICT JSON format matching the schema:
{
  "baskets": [
    {
      "sector": "Descriptive basket name",
      "tickers": ["TICKER1", "TICKER2", "TICKER3"],
      "impliedOfiTrend": "BULLISH or BEARISH or VOLATILE with brief explanation",
      "winRate": 64,
      "profitFactor": 1.55,
      "avgFrictionConsumed": 5.4
    }
  ]
}
Ensure tickers are real liquid US or European equities and ETFs (e.g. XLE, GLD, ITA, SPY, QQQ, AAPL, EURX, TSLA, COP, VLO, SAP, RWE).
Only output raw valid JSON.`;
    const ai = new import_genai3.GoogleGenAI({
      apiKey: rawKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });
    const parsedData = JSON.parse(response.text || "{}");
    if (parsedData && Array.isArray(parsedData.baskets)) {
      parsedData.baskets.forEach((b) => {
        if (Array.isArray(b.tickers)) {
          b.tickers.forEach((ticker) => {
            const sym = ticker.toUpperCase();
            if (!marketBooks[sym]) {
              const defaultExch = ["SGO", "ENGI", "RWE", "SAP", "LVMH", "ASML"].includes(sym) ? "SBF" : "NYSE";
              ingestScannedInstrument(sym, defaultExch, 100);
            }
          });
        }
      });
      try {
        import_fs8.default.writeFileSync(import_path8.default.join(process.cwd(), "dynamic_baskets.json"), JSON.stringify(parsedData, null, 2), "utf8");
      } catch (err) {
        console.error("[SERVER] Failed to write dynamic_baskets.json:", err.message);
      }
      res.json({ success: true, message: `Geopolitical Sectors successfully calibrated via Gemini for "${eventDescription.slice(0, 45)}..."`, baskets: parsedData.baskets });
    } else {
      throw new Error("Invalid structure returned from model");
    }
  } catch (err) {
    res.status(500).json({ error: "Macro calibration failed: " + err.message });
  }
});
aiRouter.post("/api/test-ai-key", async (req, res) => {
  const { provider, apiKey, baseUrl } = req.body;
  const startTime = Date.now();
  try {
    if (provider === "gemini") {
      let key = apiKey && !isMaskedString(apiKey) ? apiKey.trim() : systemSettings.geminiApiKey || process.env.GEMINI_API_KEY || "";
      if (key && isMaskedString(key)) {
        key = process.env.GEMINI_API_KEY || "";
      }
      if (!key || key === "MY_GEMINI_API_KEY" || isMaskedString(key)) {
        throw new Error("No Gemini API key supplied. Please paste your AIzaSy... key from https://aistudio.google.com/app/apikey");
      }
      if (key.startsWith("AQ.")) {
        throw new Error("Detected Google Cloud OAuth token ('AQ...'). Google Gemini API requires a standard API key starting with 'AIzaSy...' from https://aistudio.google.com/app/apikey");
      }
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${key}`);
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Google API returned ${response.status}: ${errText}`);
      }
      const data = await response.json();
      const rawModels = data.models || [];
      const discoveredModels = rawModels.filter((m) => m.supportedGenerationMethods?.includes("generateContent")).map((m) => {
        const cleanId = m.name?.replace(/^models\//, "");
        return {
          id: `google/${cleanId}`,
          rawId: cleanId,
          name: m.displayName || cleanId,
          description: m.description || "",
          provider: "Google GenAI",
          tier: cleanId.includes("flash") ? "Tier 1 Next-Gen" : "Tier 2 Deep Reasoning",
          badge: "Active Discovered",
          costStr: cleanId.includes("flash") ? "$0.10 / 1M tokens" : "$1.25 / 1M tokens",
          icon: "\u{1F48E}"
        };
      });
      if (apiKey && !isMaskedString(apiKey)) {
        saveVaultCredentials({ geminiApiKey: key });
        systemSettings.geminiApiKey = key;
        persistSettings();
      }
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        provider: "Google GenAI",
        models: discoveredModels,
        message: `Google GenAI verified. Discovered ${discoveredModels.length} active models directly from API.`
      });
    }
    if (provider === "groq") {
      let key = apiKey && !isMaskedString(apiKey) ? apiKey.trim() : systemSettings.customAiApiKey || process.env.GROQ_API_KEY || "";
      if (key && isMaskedString(key)) {
        key = process.env.GROQ_API_KEY || "";
      }
      if (!key || isMaskedString(key)) {
        throw new Error("No Groq API key supplied. Please paste your gsk_... key from https://console.groq.com/keys");
      }
      const response = await fetch("https://api.groq.com/openai/v1/models", {
        headers: { "Authorization": `Bearer ${key}` }
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Groq API returned ${response.status}: ${errText}`);
      }
      const data = await response.json();
      const rawModels = data.data || [];
      const discoveredModels = rawModels.filter((m) => m.active !== false && !m.id?.includes("whisper")).map((m) => ({
        id: `groq/${m.id}`,
        rawId: m.id,
        name: m.id,
        provider: "Groq",
        tier: m.id.includes("70b") ? "Tier 1 LPU" : "Tier 0.5 LPU",
        badge: "Ultra-Fast LPU",
        costStr: "$0.59 / 1M tokens",
        icon: "\u26A1"
      }));
      if (apiKey && !isMaskedString(apiKey)) {
        saveVaultCredentials({ customAiApiKey: key, groqApiKey: key });
        systemSettings.customAiApiKey = key;
        persistSettings();
      }
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        provider: "Groq Cloud",
        models: discoveredModels,
        message: `Groq Cloud verified. Discovered ${discoveredModels.length} active models directly from API.`
      });
    }
    if (provider === "nvidia") {
      let key = apiKey && !isMaskedString(apiKey) ? apiKey.trim() : systemSettings.nvidiaApiKey || process.env.NVIDIA_API_KEY || "";
      if (key && isMaskedString(key)) {
        key = process.env.NVIDIA_API_KEY || "";
      }
      if (!key || isMaskedString(key)) {
        throw new Error("No NVIDIA API key supplied. Please paste your nvapi-... key from https://build.nvidia.com");
      }
      const response = await fetch("https://integrate.api.nvidia.com/v1/models", {
        headers: { "Authorization": `Bearer ${key}` }
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`NVIDIA API returned ${response.status}: ${errText}`);
      }
      const data = await response.json();
      const rawModels = data.data || [];
      const discoveredModels = rawModels.map((m) => ({
        id: `nvidia/${m.id}`,
        rawId: m.id,
        name: m.id,
        provider: "NVIDIA NIM",
        tier: "Tier 1 NIM",
        badge: "NIM Microservice",
        costStr: "$0.70 / 1M tokens",
        icon: "\u{1F7E2}"
      }));
      if (apiKey && !isMaskedString(apiKey)) {
        saveVaultCredentials({ nvidiaApiKey: key });
        systemSettings.nvidiaApiKey = key;
        persistSettings();
      }
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        provider: "NVIDIA NIM",
        models: discoveredModels,
        message: `NVIDIA NIM verified. Discovered ${discoveredModels.length} active models directly from API.`
      });
    }
    if (provider === "openai") {
      let key = apiKey && !isMaskedString(apiKey) ? apiKey.trim() : systemSettings.openaiApiKey || process.env.OPENAI_API_KEY || "";
      if (key && isMaskedString(key)) {
        key = process.env.OPENAI_API_KEY || "";
      }
      if (!key || isMaskedString(key)) {
        throw new Error("No OpenAI API key supplied. Please paste your sk-... key from https://platform.openai.com/api-keys");
      }
      const response = await fetch("https://api.openai.com/v1/models", {
        headers: { "Authorization": `Bearer ${key}` }
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`OpenAI API returned ${response.status}: ${errText}`);
      }
      const data = await response.json();
      const rawModels = data.data || [];
      const discoveredModels = rawModels.filter((m) => m.id?.startsWith("gpt-") || m.id?.startsWith("o1")).map((m) => ({
        id: `openai/${m.id}`,
        rawId: m.id,
        name: m.id,
        provider: "OpenAI",
        tier: "Tier 1 Frontier",
        badge: "OpenAI Official",
        costStr: "$2.50 / 1M tokens",
        icon: "\u{1F9E0}"
      }));
      if (apiKey && !isMaskedString(apiKey)) {
        saveVaultCredentials({ openaiApiKey: key });
        systemSettings.openaiApiKey = key;
        persistSettings();
      }
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        provider: "OpenAI",
        models: discoveredModels,
        message: `OpenAI verified. Discovered ${discoveredModels.length} active models directly from API.`
      });
    }
    if (provider === "openrouter") {
      let key = apiKey && !isMaskedString(apiKey) ? apiKey.trim() : systemSettings.openrouterApiKey || process.env.OPENROUTER_API_KEY || "";
      if (key && isMaskedString(key)) {
        key = process.env.OPENROUTER_API_KEY || "";
      }
      const headers = { "User-Agent": "AlphaEngine/2.0" };
      if (key) headers["Authorization"] = `Bearer ${key}`;
      const response = await fetch("https://openrouter.ai/api/v1/models", { headers });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`OpenRouter API returned ${response.status}: ${errText}`);
      }
      const data = await response.json();
      const rawModels = data.data || [];
      const discoveredModels = rawModels.filter((m) => {
        const mid = (m.id || "").toLowerCase();
        const pPrompt = parseFloat(m.pricing?.prompt || "0");
        return mid.includes(":free") || pPrompt === 0 || mid.includes("deepseek") || mid.includes("qwen") || mid.includes("nemotron") || mid.includes("llama-3.3");
      }).slice(0, 30).map((m) => ({
        id: `openrouter/${m.id}`,
        rawId: m.id,
        name: m.name || m.id,
        provider: "OpenRouter",
        tier: m.id.includes(":free") ? "Free Tier" : "Tier 1 OpenRouter",
        badge: m.id.includes(":free") ? "\u{1F381} FREE" : "OpenRouter",
        costStr: m.id.includes(":free") ? "$0.00 / 1M tokens" : `$${(parseFloat(m.pricing?.prompt || "0") * 1e6).toFixed(2)} / 1M`,
        icon: m.id.includes(":free") ? "\u{1F381}" : "\u{1F310}",
        isFree: m.id.includes(":free")
      }));
      if (apiKey && !isMaskedString(apiKey)) {
        saveVaultCredentials({ openrouterApiKey: key });
        systemSettings.openrouterApiKey = key;
        persistSettings();
      }
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        provider: "OpenRouter",
        models: discoveredModels,
        message: `OpenRouter verified. Discovered ${discoveredModels.length} models directly from OpenRouter API.`
      });
    }
    if (provider === "custom") {
      const targetUrl = baseUrl || systemSettings.customAiBaseUrl || "http://localhost:11434/v1";
      const modelsEndpoint = targetUrl.endsWith("/") ? `${targetUrl}models` : `${targetUrl}/models`;
      const response = await fetch(modelsEndpoint);
      if (!response.ok) {
        throw new Error(`Custom endpoint returned ${response.status}`);
      }
      const data = await response.json();
      const rawModels = data.data || data.models || [];
      const discoveredModels = rawModels.map((m) => {
        const mid = typeof m === "string" ? m : m.id || m.name || "custom-model";
        return {
          id: `custom/${mid}`,
          rawId: mid,
          name: mid,
          provider: "Custom Local",
          tier: "Tier 0 Self-Hosted",
          badge: "Local Runtime",
          costStr: "$0.00 (Self-Hosted)",
          icon: "\u{1F999}"
        };
      });
      const latencyMs = Date.now() - startTime;
      return res.json({
        success: true,
        latencyMs,
        provider: "Custom Endpoint",
        models: discoveredModels,
        message: `Custom endpoint verified. Discovered ${discoveredModels.length} models.`
      });
    }
    throw new Error(`Unsupported provider for test: ${provider}`);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message, message: err.message });
  }
});
aiRouter.get("/api/models/live-catalog", async (req, res) => {
  res.redirect("/api/copilot/models");
});

// server.ts
console.log("[ALPHA SERVER] Initializing institutional modular server...");
var activeTrades2 = [];
var historicalLogs2 = [];
var app = (0, import_express9.default)();
app.use(import_express9.default.json());
app.get("/healthz", (req, res) => {
  res.status(200).send("OK");
});
app.use(riskRouter);
app.use(ordersRouter);
app.use(eventsRouter);
app.use(backtestRouter);
app.use(systemRouter);
app.use(aiRouter);
app.use(researchRouter);
app.use(copilotRouter);
process.on("unhandledRejection", (reason, promise) => {
  console.error("[SERVER] Unhandled Rejection at:", promise, "reason:", reason);
});
process.on("uncaughtException", (err) => {
  console.error("[SERVER] Uncaught Exception:", err);
});
async function startServer() {
  await loadPersistentSettings();
  const distPath = import_path9.default.join(process.cwd(), "dist");
  const distExists = import_fs9.default.existsSync(import_path9.default.join(distPath, "index.html"));
  if (process.env.NODE_ENV === "production" || distExists) {
    console.log("[ALPHA SERVER] Serving production static bundle from /dist");
    app.use(import_express9.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path9.default.join(distPath, "index.html"));
    });
  } else {
    console.log("[ALPHA SERVER] Initializing Vite dev middleware...");
    delete process.env.PORT;
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  }
  const listenPort = Number(process.env.PORT) || 3e3;
  app.listen(listenPort, "0.0.0.0", () => {
    console.log(`[ALPHA SERVER] Running successfully on port: http://0.0.0.0:${listenPort}`);
  });
}
startServer();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  activeTrades,
  authMiddleware,
  getMaskedSettings,
  historicalLogs,
  systemSettings
});
//# sourceMappingURL=server.cjs.map
